
 STRONY BLEDOW/HISTORII/DATY   X

    1) Ustawienie DATY i GODZ
    2) Strony WYSW. HISTORII
    3) Strony POMOC. BLED.
    4) ...   
    5) STATYSTYKI


    4) Wydruk historii


    
    
    
    
    
    