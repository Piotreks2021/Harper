
  Blad 1:      ---                                                                      ---
  Opis:        ---                                                                      ---
               ---                                                                      ---
  Blad 2:      ---                                                                      ---
  Opis:        ---                                                                      ---
               ---                                                                      ---


                                                        POPRZ [-]      NAST [+]    ZAMKNIJ   


                                                       xxxxxxxxxxxx  xxxxxxxxxxxx  xxxxxxxx 
                                                                               
