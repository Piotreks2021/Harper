
    WCISNIJ ENTER ABY POTWIERDZIC
    ZAMKNIECIE APLIKACJI
                                          
                      ENTER     ANULUJ    
                                          
                                          

                    xxxxxxxxx  xxxxxxxxx
  