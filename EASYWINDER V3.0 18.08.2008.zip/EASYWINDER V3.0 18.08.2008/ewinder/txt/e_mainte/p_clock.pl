
                                             X 
   FORMAT daty :

   DZIEN         MIESIAC      ROK  

   GODZINA       MINUT        SEKUND 


                           ZASTOSUJ   ANULUJ  


                          xxxxxxxxx  xxxxxxxxx
                                         