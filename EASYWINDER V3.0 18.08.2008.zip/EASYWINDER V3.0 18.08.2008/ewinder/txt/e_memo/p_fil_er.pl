  
  BLAD PRZEPISOW!                     X


