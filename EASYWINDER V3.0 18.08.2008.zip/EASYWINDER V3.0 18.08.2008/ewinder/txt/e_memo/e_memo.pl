
  TRYB PRZEPISY:                           X

  Zrodlo 

  Numer                            +      -

  Kod   
  
  Data utworzenia (m/d/y)
  Ostatnio uzywany(m/d/y)
  
    [F1] Odczyt przep.   [F3] Akcept. nowy


    [F2] Zapisz przep.   [F4] Przywroc stary




  xxxxxxxxxxxxxxxxxxxx   xxxxxxxxxxxxxxxxxxxx

