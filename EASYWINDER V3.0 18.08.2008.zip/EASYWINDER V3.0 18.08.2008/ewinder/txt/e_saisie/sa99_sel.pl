
                                      X  

 
   +      -     ENTER          
