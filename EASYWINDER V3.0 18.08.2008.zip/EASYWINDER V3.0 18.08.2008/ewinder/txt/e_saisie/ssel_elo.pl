
                                      X  

 
   +      -      OK
