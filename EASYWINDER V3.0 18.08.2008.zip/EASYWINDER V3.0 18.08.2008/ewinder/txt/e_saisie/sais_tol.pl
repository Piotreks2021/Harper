  zadana wartosc  =
                                         
 [min:               maks:               ] 
/* msg_refu_saisie[]       */   " Poza zakresem: wcisnij przycisk      "
/* msg_saisie_numerique[]  */   " Wczytanie warto�ci numerycznej       "
/* msg_saisie_hexa[]       */   " Wczytanie wartosci heksagonalnej     "
/* msg_saisie_oct[]        */   " Wczytanie wartosci osemkowej         "
/* msg_saisie_bin[]        */   " Wczytanie wartosci dwojkowej         "
/* msg_saisie_entiere[]    */   " Wczytanie wartosci calkowitej        "
