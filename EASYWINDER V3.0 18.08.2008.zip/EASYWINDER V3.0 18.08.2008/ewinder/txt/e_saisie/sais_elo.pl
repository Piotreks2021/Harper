  Desired value  =                        
                                         
 [min:               max:               ] 
/* msg_refu_saisie[]       */   " Out of range: push a key             "
/* msg_saisie_numerique[]  */   " Numerical value capture              "
/* msg_saisie_hexa[]       */   " Hexa. value capture                  "
/* msg_saisie_oct[]        */   " Octal value capture                  "
/* msg_saisie_bin[]        */   " Binary value capture                 "
/* msg_saisie_entiere[]    */   " Integer value capture                "
