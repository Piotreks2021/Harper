
   7      8      9                          X

                    
   4      5      6     
                      Min:
                      
   1      2      3    Max:
               
 
   0      .      -    ENTERSUJ          ANULUJ


" Out of range  "   /* msg_refu_saisie[]       */
" Num. capture  "   /* msg_saisie_numerique[]  */
" Hexa.capture  "   /* msg_saisie_hexa[]       */
" Octal capture "   /* msg_saisie_oct[]        */
" Bin. capture  "   /* msg_saisie_bin[]        */
" Integer capt. "   /* msg_saisie_entiere[]    */

