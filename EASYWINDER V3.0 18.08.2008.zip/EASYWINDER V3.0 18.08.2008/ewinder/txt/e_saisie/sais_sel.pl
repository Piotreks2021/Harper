 Wybierz strzalka      + lub -          
                                    
