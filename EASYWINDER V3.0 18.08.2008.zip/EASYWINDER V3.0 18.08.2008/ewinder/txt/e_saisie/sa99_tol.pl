
   7      8      9                          X

                    
   4      5      6     
                      Min:
                      
   1      2      3    Maks:
               
 
   0      .      -     ENTER               SKAS


" Poza zakresem "   /* msg_refu_saisie[]       */
" Wczytaj numer."   /* msg_saisie_numerique[]  */
" Wczytaj heks. "   /* msg_saisie_hexa[]       */
" Wczytaj osemk."   /* msg_saisie_oct[]        */
" Wczytaj dwojk."   /* msg_saisie_bin[]        */
" Wczytaj calk. "   /* msg_saisie_entiere[]    */

