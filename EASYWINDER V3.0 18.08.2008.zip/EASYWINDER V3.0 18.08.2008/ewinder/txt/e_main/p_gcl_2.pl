
  UKLAD CIECIA(GCL) STEROWANIE RECZNE   X


     ZALOZ OSTRZA         USUN OSTRZA
          [1]                 [2]       


      OBROT PRZOD          OBROT TYL
          [3]                 [4]       


      ODCIAG WL.          ODCIAG WYL.
          [5]                 [6]       


       BLOK. UKLAD        ODBLOK UKLAD
          [7]                 [8]       


12345678901234567890123456789012345678901234
  
----xxxxxxxxxxxxxxxx----xxxxxxxxxxxxxxxx----

  