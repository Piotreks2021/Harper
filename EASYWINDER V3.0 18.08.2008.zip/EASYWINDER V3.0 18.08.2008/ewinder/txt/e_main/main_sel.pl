/* Tableau des defauts.                                      */
/* char *tbl_message_defaut[] =                              */
/*                                 12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234.234567890123456789012345678901234567890123456789012345678901234567890123456.234567890123456789012345678901234567890123456789012345678901234567890123456*/
char far tbl_message_defaut00[]  ="                                                                                                                                                                                                                                                                ";

/* Pr_Mot_Def_grave1  1-16 *************************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut01[] = "DG001. Stan awaryjny na linii produkcji                                                       (CAN1.1.1)Jedna z maszyn w linii produkcji wywolala zadanie zatrzymania awaryjnego.   Usunac awarie odpowiedniej maszyny i sprawdzic wejscie (CAN1.1.1)           ";
char far tbl_message_defaut02[] = "DG002. Wcisnieto przycisk awaryjny                                                            (CAN1.2.5)Wcisnieto przynajmniej jeden przycisk awaryjny maszyny. Zwolnic wszystkie   przyciski awaryjne lub sprawdzic odpowiednie wejscie (CAN1.2.5)             ";
char far tbl_message_defaut03[] = "DG003. Stan awaryjny na glownym lub pomocniczym module bezpieczenstwa              (CAN1.2.1 - CAN1.2.2)Sprzetowa sekwencja awaryjna uruchomiona awaryjnym przyciskiem, na linii    produkcji lub przez oprogramowanie sterujace. Wyzerowac maszyne             ";
char far tbl_message_defaut04[] = "DG004. Alarm czujnika cisnienia powietrza                                                     (CAN2.1.6)Cisnienie w obwodzie pneumatycznym jest zbyt niskie.       Sprawdzic glowne cisnienie, wlaczyc manometr maszyny lub sprawdzic wejscie (CAN1.2.5)        ";
char far tbl_message_defaut05[] = "DG005. Alarm przekroczono czas zatrzymania maszyny                                                      Maszyna nie zwolnila w dopuszczalnym skonfigurowanym czasie.                (Jesli problem sie utrzyma, skontaktowac sie ze sprzedawca)                 ";
char far tbl_message_defaut06[] = "DG006. Alarm OTWARTE DRZWI BEZPIECZEnSTWA                                                     (CAN1.2.4)Zamknac drzwi lub sprawdzic wejscie (wejscia)                                                                                                           ";
char far tbl_message_defaut07[] = "DG007. Stan awaryjny na maszynie A                                                            (CAN1.1.3)Zadanie zatrzymania awaryjnego z maszyny A.                                 Usunac awarie odpowiedniej maszyny lub sprawdzic wejscie (CAN . . )         ";
char far tbl_message_defaut08[] = "DG008. Stan awaryjny na maszynie B                                                            (CAN . . )Zadanie zatrzymania awaryjnego z maszyny B.                                 Usunac awarie odpowiedniej maszyny lub sprawdzic wejscie (CAN . . )         ";
char far tbl_message_defaut09[] = "DG009. Alarm rezystor hamujacy (szyna pradu stalego)                                          (CAN1.2.6)Blad przekroczenia temperatury z rezystora hamujacego                       Sprawdzic przyczyny, poczekac na ochlodzenie lub sprawdzic wejscie rozwierne";
char far tbl_message_defaut10[] = "DG010. Wymuszony alarm podczas automatycznej zmiany walu (po zadaniu operatora)                         Zadanie zatrzymania podczas wykonywania automatycznej wymiany.              Operator zazadal zatrzymania, wciskajac STOP MACHINE wiecej niz 5 razy.     ";
char far tbl_message_defaut11[] = "DG011. Alarm BUS-OFF z sieci 2 CanOpen (zdalne moduly We/Wy)                                            Sprawdzic status modulow We/Wy. Sprawdzic kable sieciowe, polaczenia i      rezystory w zlaczach. Sprawdzic ustawienia modulow We/Wy.                   ";
char far tbl_message_defaut12[] = "DG012. Alarm przy odczycie plikow konfiguracyjnych sieci 2 CanOpen (zdalne moduly We/Wy)                Sprawdzic status modulow We/Wy. Sprawdzic kable sieciowe, polaczenia i      rezystory w zlaczach. Sprawdzic ustawienia modulow We/Wy.                   ";
char far tbl_message_defaut13[] = "DG013. Alarm przy odbiorze PDO sieci 2 CanOpen (zdalne moduly We/Wy)                                    Sprawdzic status modulow We/Wy. Sprawdzic kable sieciowe, polaczenia i      rezystory w zlaczach. Sprawdzic ustawienia modulow We/Wy.                   ";
char far tbl_message_defaut14[] = "DG014. Alarm przy odbiorze bledow z sieci 2 CanOpen Network (zdalne moduly We/Wy)                       Sprawdzic status modulow We/Wy. Sprawdzic kable sieciowe, polaczenia i      rezystory w zlaczach. Sprawdzic ustawienia modulow We/Wy.                   ";
char far tbl_message_defaut15[] = "DG015. Alarm BUS-OFF z sieci 1 CanOpen (NAPeDY SILNIKOWE)                                               Sprawdzic status napedow silnikowych. Sprawdzic kable sieciowe, polaczenia  i rezystory w zlaczach. Sprawdzic ustawienia napedow.                       ";
char far tbl_message_defaut16[] = "DG016. Alarm przy odczycie plikow konfiguracyjnych sieci 1 CanOpen (NAPeDY SILNIKOWE)                   Sprawdzic status napedow silnikowych. Sprawdzic kable sieciowe, polaczenia  i rezystory w zlaczach. Sprawdzic ustawienia napedow                        ";

/* Pr_Mot_Def_grave2 17-32 *************************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut17[] = "DG017. Alarm niezablokowane szczypce na pomocniczych wozkach (LOCK_CS)             (CAN2.2.1 - CAN2.2.3)W CS wykryto status szczypiec UNLOCKED (niezablokowane) w trybie            automatycznym, przez czas dluzszy niz 2 sekundy.                            ";
char far tbl_message_defaut18[] = "DG018. Alarm niezablokowane szczypce na glownych wozkach (LOCK_CP)                 (CAN2.3.6 - CAN2.4.2)W CP wykryto status szczypiec UNLOCKED (niezablokowane) podczas             automatycznej zmiany walu, przez czas dluzszy niz 2 sekundy.                ";
char far tbl_message_defaut19[] = "DG019. Alarm magnet. przelacznik temperaturowy na glownych wozkach obrotu silnika (ROT_CP)    (CAN1.3.3)Aktualne przeciazenie odpowiedniego silnika. Sprawdzic przyczyny, wlaczyc   ponownie urzadzenie w szafce lub sprawdzic wejscie.                         ";
char far tbl_message_defaut20[] = "DG020. Alarm magnet. przelacznik temp. na hamulcu na gl. wozkach obrotu silnika (ROT_CP)      (CAN1.3.2)Aktualne przeciazenie hamulca odpowiedniego silnika.Sprawdzic przyczyny,    wlaczyc ponownie urzadzenie w szafce lub sprawdzic wejscie.                 ";
char far tbl_message_defaut21[] = "DG021. Alarm magn. przelacznik temp. na hamulcu w silniku obr. w ukladzie splatania (ROT_SR)  (CAN1.3.1)Aktualne przeciazenie hamulca odpowiedniego silnika. Sprawdzic przyczyny,   wlaczyc ponownie urzadzenie w szafce lub sprawdzic wejscie.                 ";
char far tbl_message_defaut22[] = "DG022. Zadanie synchronizowanego zatrzymania maszyny na linii produkcji                                 Zadanie szybkiego zatrzymania wyslane na linie prod. z powodu alarmu wewn.  Jesli linia nie zatrzyma sie w okreslonym czasie nastapi zatrzymanie awaryjn";
char far tbl_message_defaut23[] = "DG023. Alarm temperatura jednego lub wiecej silnikow w ukladzie ciecia (ROT_GCL)              (CAN1.3.6)Temp. jednego lub wiecej silnikow jest zbyt wysoka. Zatrzymac maszyne,      sprawdzic przyczyny,sprawdzic cyfrowe wejscie lub wylaczyc odpowiedni silnik";
char far tbl_message_defaut24[] = "DG024. Wlaczona linia awaryjna                                                                (CAN1.1.6)Linia awaryjna ukladu ciecia zostala wlaczona.                              Przywrocic status gotowosci linii awaryjnej lub sprawdzic cyfr. wejscie     ";
char far tbl_message_defaut06[] = "DG025. Alarm OTWARTE DRZWI NISKIEJ PREDKOSCI                                                  (CAN1.1.4)Zamknac drzwi lub sprawdzic wejscia                                                                                                                     ";
char far tbl_message_defaut26[] = "DG026. Emergency from the TRANSLATION TABLE                                                   (CAN1.5.2)Emergency Request coming from the Translational Table.                      Release the Emergency or check the relative input digital input.            ";
char far tbl_message_defaut27[] = "DG027. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut28[] = "DG028. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut29[] = "DG029. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut30[] = "DG030. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut31[] = "DG031. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut32[] = "DG032. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_Def_grave3 33-48 *************************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut33[] = "DG033. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut34[] = "DG034. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut35[] = "DG035. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut36[] = "DG036. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut37[] = "DG037. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut38[] = "DG038. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut39[] = "DG039. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut40[] = "DG040. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut41[] = "DG041. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut42[] = "DG042. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut43[] = "DG043. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut44[] = "DG044. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut45[] = "DG045. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut46[] = "DG046. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut47[] = "DG047. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut48[] = "DG048. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_Def_grave4 49-64 *************************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut49[] = "DG049. BLAD OSI na ROT_RP1: obrot BeBNA NAWIJANIA #1  (zobacz rodzaj bledu w nastepnej linii komunikatu)                                                                                                                                                        ";
char far tbl_message_defaut50[] = "DG050. BLAD OSI na ROT_DEP: obrot WALU NACIAGOWEGO    (zobacz rodzaj bledu w nastepnej linii komunikatu)                                                                                                                                                        ";
char far tbl_message_defaut51[] = "DG051. BLAD OSI na ROT_REM: obrot NAPEDZANEGO WALU WPROWADZAJACEGO                                      (zobacz rodzaj bledu w nastepnej linii komunikatu)                                                                                                      ";
char far tbl_message_defaut52[] = "DG052. BLAD OSI na ROT_ABF: obrot OSI PUSTEGO WALU    (zobacz rodzaj bledu w nastepnej linii komunikatu)                                                                                                                                                        ";
char far tbl_message_defaut53[] = "DG053. BLAD OSI na ROT_GCL: obrot w UKLADZIE CIeCIA   (zobacz rodzaj bledu w nastepnej linii komunikatu)                                                                                                                                                        ";
char far tbl_message_defaut54[] = "DG054. BLAD OSI na ROT_SR : obrot w UKLADZIE SPLATANIA(zobacz rodzaj bledu w nastepnej linii komunikatu)                                                                                                                                                        ";
char far tbl_message_defaut55[] = "DG055. BLAD OSI na ROT_RP2: obrot BeBNA NAWIJANIA #2  (zobacz rodzaj bledu w nastepnej linii komunikatu)                                                                                                                                                        ";
char far tbl_message_defaut56[] = "DG056. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut57[] = "DG057. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut58[] = "DG058. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut59[] = "DG059. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut60[] = "DG060. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut61[] = "DG061. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut62[] = "DG062. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut63[] = "DG063. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut64[] = "DG064. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_Def_grave5 65-80 *************************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut65[] = "DG065. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut66[] = "DG066. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut67[] = "DG067. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut68[] = "DG068. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut69[] = "DG069. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut70[] = "DG070. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut71[] = "DG071. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut72[] = "DG072. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut73[] = "DG073. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut74[] = "DG074. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut75[] = "DG075. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut76[] = "DG076. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut77[] = "DG077. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut78[] = "DG078. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut79[] = "DG079. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut80[] = "DG080. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_Def_grave6 81-96 *************************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut81[] = "DG081. OSIOWY TYP BLEDU: ALARM NAPeDU (lub siec 1 CanOpen odlaczona od napedu)                          Odpowiedni naped ma status bledu. Sprawdzic numer bledu w historii bledow   napedu i porownac z odnosnikiem lub podrecznikiem uzytkownika.              ";
char far tbl_message_defaut82[] = "DG082. OSIOWY TYP BLEDU: ALARM SERWOMECHANIZMU                                                          BLAD UTRZYMANIA PReDKOsCI byl wiekszy od maks. ustawionej wartosci.         Jesli problem sie utrzyma, skontaktowac sie z serwisem posprzedazowym.      ";
char far tbl_message_defaut83[] = "DG083. OSIOWY TYP BLEDU: ALARM KOLIZJI                                                                  BLAD UTRZYMANIA PReDKOsCI byl zbyt duzy podczas zatrzymania osi.            Jesli problem sie utrzyma, skontaktowac sie z serwisem posprzedazowym.      ";
char far tbl_message_defaut84[] = "DG084. OSIOWY TYP BLEDU: ALARM SOFTWARE-EXTRALIMIT                                                      Pozycja osi byla wyzsza (nizsza), niz maksymalna (minimalna) skonfigurowana wartosc.Jesli problem sie utrzyma,skontaktowac sie z serwisem posprzedazowym";
char far tbl_message_defaut85[] = "DG085. OSIOWY TYP BLEDU: PRZEPELNIENIE DODATNIE DAC                                                     SZYBKOSC ODNIESIENIA zadana przez algorytm sterowania nadazaniem osi byla ZBYT DUZA.Jesli problem sie utrzyma,skontaktowac sie z serwisem posprzedazowym";
char far tbl_message_defaut86[] = "DG086. OSIOWY TYP BLEDU: PRZEPELNIENIE UJEMNE DAC                                                       PREDKOSC ODNIESIENIA zadana przez algorytm sterowania nadazaniem osi byla ZBYT NISKA.Jesli problem sie utrzyma,skontaktowac sie z serwisem posprzedazowy";
char far tbl_message_defaut87[] = "DG087. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut88[] = "DG088. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut89[] = "DG089. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut90[] = "DG090. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut91[] = "DG091. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut92[] = "DG092. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut93[] = "DG093. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut94[] = "DG094. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut95[] = "DG095. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut96[] = "DG096. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_Def_grave7 97-112*************************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut97[] = "DG097. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut98[] = "DG098. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut99[] = "DG099. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut100[]= "DG100. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut101[]= "DG101. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut102[]= "DG102. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut103[]= "DG103. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut104[]= "DG104. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut105[]= "DG105. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut106[]= "DG106. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut107[]= "DG107. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut108[]= "DG108. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut109[]= "DG109. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut110[]= "DG110. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut111[]= "DG111. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut112[]= "DG112. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_Def_simple1 113-128 **********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut113[]= "DS001. Blad OTWARTE DRZWI BEZP. --> (UWAGA: 15 sekund do zadania zatrzymania awaryjnego)      (CAN1.2.4)Zamknac drzwi lub zatrzymac maszyne. Jesli wszystkie drzwi sa zamkniete,    zatrzymac maszyne i sprawdzic odpowiednie wejscia.                          ";
char far tbl_message_defaut114[]= "DS002. Sygnal polaczenia z detektora metali                                                   (CAN . . )Detektor metali wykryl defekt w produkcie i/lub wyslal sygnal do            odpowiedniego wejscia w maszynie (CAN . . )                                 ";
char far tbl_message_defaut115[]= "DS003. Blad w pomocniczym module bezpieczenstwa                                               (CAN1.2.2)Sprzetowy ciag awaryjny otworzony w linii produkcji przez oprogramowanie    sterujace. Najpierw wyzerowac linie, wyzerowac maszyne lub sprawdzic wejscie";
char far tbl_message_defaut116[]= "DS004. Blad szczypce w pomocniczych wozkach nie zablokowane (LOCK_CS)              (CAN2.2.1 - CAN2.2.3)Status szczypiec UNLOCKED (nie zablokowane) wykryto w trybie                automatycznym. Dwie sekundy do zadania awaryjnego zatrzymania maszyny.      ";
char far tbl_message_defaut117[]= "DS005. Alarm szczypce w glownych wozkach nie zablokowane (LOCK_CP)                 (CAN2.3.6 - CAN2.4.2)Status szczypiec UNLOCKED (nie zablokowane) wykryto podczas automatycznej   zmiany walu. Dwie sekundy do zadania awaryjnego zatrzymania maszyny.        ";
char far tbl_message_defaut118[]= "DS006. Alarm magnetyczny przelacznik temperaturowy silnika podawania produktu                 (CAN1.3.4)Aktualne przeciazenie odpowiedniego silnika. Sprawdzic przyczyny, wlaczyc   ponownie urzadzenie w szafce lub sprawdzic wejscie.                         ";
char far tbl_message_defaut119[]= "DS007. Alarm temperatura jednego lub wiecej silnikow w ukladzie ciecia (ROT_GCL)              (CAN1.3.6)Temperatura przynajmniej jednego silnika jest zbyt wysoka.Zatrzymac maszyne,sprawdzic przyczyny,sprawdzic cyfrowe wejscie lub wylaczyc odpowiedni silnik";
char far tbl_message_defaut120[]= "DS008. Alarm temperatura silnika odciagu brzegow                                              (CAN1.3.5)Temperatura jest zbyt wysoka. Zatrzymac odciaganie brzegow, sprawdzic       przyczyny i/lub sprawdzic cyfrowe wejscie.                                  ";
char far tbl_message_defaut121[]= "DS009. Blad OTWARTE DRZWI BEZP. N. PReDK. --> (UWAGA: 5 sekund do awaryjnego zatrzymania)     (CAN1.1.4)Zamknac drzwi lub zatrzymac maszyne. Jesli wszystkie drzwi sa zamkniete,    zatrzymac maszyne i sprawdzic odpowiednie wejscia.                          ";
char far tbl_message_defaut122[]= "DS010. Osiagniecie MAKSYMALNEJ SREDNICY TOCZENIA: zostalo wykonane polecenie automatycznej zmiany lub ..zatrzymania maszyny. W miare mozliwosci zostanie wykonana automatyczna      zmiana, w przeciwnym razie maszyna zostanie zatrzymana.                     ";
char far tbl_message_defaut123[]= "DS011. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut124[]= "DS012. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut125[]= "DS013. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut126[]= "DS014. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut127[]= "DS015. Miss LOADED REEL on the CRANE (safety timer ended)              (CAN3.1.3 or CAN3.7.3 - CAN3.7.4)The Reel (or Shaft) has not been properly loaded on the crane within the    requested time (5sec). Verify the reasons and/or check the relative inputs. ";
char far tbl_message_defaut128[]= "DS016. Miss REEL LOADING POSITION of the CRANE (safety timer ended)                (CAN3.6.1 - CAN3.6.2)The REEL LOADING POSITION correspondent to the proximity switches indicated into the message has not been reached within the requested time (5sec).     ";
                                                                                                                                           
/* Pr_Mot_Def_simple2 129-144 **********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut129[]= "DS017. The Crane has been DEACTIVATED                                                          (CAN3.1.1)Activate manually the Crane or wait for its automatic activation.          If necessary, verify the input indicated into the message.                  ";
char far tbl_message_defaut130[]= "DS018. CARNE's DRIVE FAULT                                                                     (CAN3.1.5)The Drive(s) of the Crane is(are) in FAULT CONDITION. Verify the reasons,  reset the Crane and/or verify the input indicated into the message.         ";
char far tbl_message_defaut131[]= "DS019. CARNE's THERMAL PROTECTION FAULT                                                        (CAN3.1.6)A thermal protection fault signal has been activated by the crane. Verify  the reasons,reset the Crane and/or verify the input indicated in the message";
char far tbl_message_defaut132[]= "DS020. EXCESSIVE LOAD on the Crane                                                             (CAN3.1.2)The load present on the Crane is TOO HEAVY. Move down the Crane and reduce the load. If necessary, verify the input indicated into the message.        ";
char far tbl_message_defaut133[]= "DS021. ZERO (LOWEST) LOAD on the Crane (possible lightening due to external contacts)          (CAN3.1.4)The load present on the Crane is TOO LOW. Move up the Crane.               If necessary, verify the input indicated into the message.                  ";
char far tbl_message_defaut134[]= "DS022. LOW PRESSURE into the air-pressure-switch of the PIN for the shafts INFLATION/DEFLATION (CAN3.8.5)The requested action or execution isn't allowed.                           Verify the main pressure and/or check the relative digital input.           ";
char far tbl_message_defaut135[]= "DS023. FAULT from CRANE's SAFETY BARRIER (CRANE STOPPED or PAUSED)                             (CAN1.6.1)The movement of the crane has been deactivated (or paused) due to the faultof the Safety Barrier. Reset the Barrier or check the relative digital input";
char far tbl_message_defaut136[]= "DS024. CRANE in SAFETY STOP                                                                    (CAN1.5.3)The STOP pushbutton of the CRANE has been pressed                          Release the pushbutton or check the the relative digital input              ";
char far tbl_message_defaut137[]= "DS025. WARNING: READING ERROR of Proximity-Switches on REEL-LOADING-POSITION of the CRANE    (CAN3.6.1-2)INCORRECT DETECTION of the 2 Safety-Switches on the reel-loading-position. Verify their status or check the relative digital inputs.                   ";
char far tbl_message_defaut138[]= "DS026. WARNING: CRANE's Local Control Activated                                                (CAN1.6.3)The local control of the Crane has been selected; each requested movements will be performed without any checking of the control software.             ";
char far tbl_message_defaut139[]= "DS027. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut140[]= "DS028. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut141[]= "DS029. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut142[]= "DS030. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut143[]= "DS031. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut144[]= "DS032. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_Def_simple3 145-160 **********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut145[]= "DS033. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut146[]= "DS034. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut147[]= "DS035. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut148[]= "DS036. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut149[]= "DS037. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut150[]= "DS038. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut151[]= "DS039. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut152[]= "DS040. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut153[]= "DS041. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut154[]= "DS042. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut155[]= "DS043. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut156[]= "DS044. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut157[]= "DS045. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut158[]= "DS046. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut159[]= "DS047. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut160[]= "DS048. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_evnmt_majeur1 161-176 ********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut161[]= "001. Komunikat: Zadanie ruchu osi CIAGLE AKTYWNE                                                        Zadane dzialanie nie jest dozwolone.                                        Zatrzymac ruch lub poczekac na zatrzymanie kazdej osi.                      ";
char far tbl_message_defaut162[]= "002. Komunikat: OTWARTE DRZWI BEZPIECZEnSTWA                                                            Zadane dzialanie nie jest dozwolone.                                        Zamknac drzwi i/lub sprawdzic odpowiednie wejscia.                          ";
char far tbl_message_defaut163[]= "003. Komunikat: Obrot glownych wozkow, nie sa w pozycji spoczynkowej (ROT_CP)                 (CAN2.3.4)Zadane dzialanie nie jest dozwolone.                                        Obrocic wozki pomocnicze do pozycji spoczynkowej lub sprawdzic wejscie.     ";
char far tbl_message_defaut164[]= "004. Komunikat: W wozkach pomocniczych szczypce nie sa w pozycji zabl.   (LOCK_CS) (CAN2.2.1 - CAN2.2.3)Zadane dzialanie nie jest dozwolone.                                        Zablokowac szczypce w wozkach pomocniczych (CS) lub sprawdzic wejscia.      ";
char far tbl_message_defaut165[]= "005. Komunikat: Sygnal BRAK ZEZWOLENIA NA ROZPOCZeCIE z linii produkcji                       (CAN1.1.2)Zadane dzialanie nie jest dozwolone.                                        Poczekac na sygnal z linii produkcji lub sprawdzic odpowiednie wejscie.     ";
char far tbl_message_defaut166[]= "006. Komunikat: Naped osi srodkowej w wozku glownym nie jest w pozycji spoczynkowej (ENG_CP)  (CAN2.5.3)Zadane dzialanie nie jest dozwolone.                                        Odlaczyc naped srodkowej osi wozka glownego lub sprawdzic wejscie.          ";
char far tbl_message_defaut167[]= "007. Komunikat: Wal w pomocniczym wozku (CS) nie jest zablokowany                                       CS sa zbyt blisko bebna nawijania RP1 i nie jest mozliwe zablokowanie na nichwalu. Jesli problem sie utrzyma, skontaktowac sie z serwisem posprzedazowym";
char far tbl_message_defaut168[]= "008. Komunikat: Wozki pomocnicze nie sa dosuniete (APPL_CS)                                             Zadane dzialanie nie jest dozwolone. Zablokowac wal w wozkach pomocniczych  CS i dosunac je do bebna nawijania 1 RP1                                    ";
char far tbl_message_defaut169[]= "009. Komunikat: ZADANIE ZATRZYMANIA przez operatora podczas wykonywania funkcji Nowy wal                Wykonanie funkcji nowego walu zostalo zatrzymane poprzez dwukrotne          wcisniecie przycisku STOP MACHINE.                                          ";
char far tbl_message_defaut170[]= "010. Komunikat: ZADANIE PRZERWANIA przez operatora podczas wykonywania funkcji Nowy wal                 Wykonanie funkcji Nowy wal zostalo zatrzymane przez jednokrotne wcisniecie  przycisku STOP MACHINE.Wcisnac przycisk START MACHINE,aby wznowic wykonywani";
char far tbl_message_defaut171[]= "011. Komunikat: Szczypce w glownych wozkach nie sa w pozycji zablokowanej lub odblokowanej (LOCK_CP)    Zadane dzialanie nie jest dozwolone.                                        Odblokowac lub zablokowac szczypce w gl. wozkach (CP) lub sprawdzic wejscia ";
char far tbl_message_defaut172[]= "012. Komunikat: Brak cisnienia powietrza                                                      (CAN2.1.6)Zadane dzialanie nie jest dozwolone. Cisnienie w obwodzie pneum. zbyt niskieSprawdzic gl.cisnienie powietrza,wlaczyc manometr maszyny lub sprawdzic wej ";
char far tbl_message_defaut173[]= "013. Komunikat: AUTOMATYCZNA ZMIANA NIEDOZWOLONA --> Pozycja rozladowania nie jest swobodna   (CAN2.5.6)Nie mozna rozpoczac sekwencji automatycznej zmiany.                         Zdjac rolke (lub wal) z pozycji rozladowania lub sprawdzic wejscie.         ";
char far tbl_message_defaut174[]= "014. Komunikat: Brak sygnalu gotowosci ze wstrzymujacego modulu bezpieczenstwa                (CAN1.2.3)Zadane dzialanie niedozwolone. Modul bezpieczenstwa nie jest jeszcze gotowy.Czekac na sygnal (logiczne 0) lub sprawdzic odpowiednie wejscie.            ";
char far tbl_message_defaut175[]= "015. Komunikat: Czas oczekiwania przed zerowaniem jeszcze NIE UPLYNAL                                   Aby zapobiec uszkodzeniu napedow silnikowych nie mozna zazadac wyzerowania  maszyny az do calkowitego rozladowania szyny pradu stalego.                 ";
char far tbl_message_defaut176[]= "016. Komunikat: Krzywki parkowania walow nie sa w pozycji poczatkowej (CAM_MABF)              (CAN2.6.4)Zadane dzialanie nie jest dozwolone.                                        Przesunac krzywki do ich poczatk. pozycji (Travail) lub sprawdzic wejscia.  ";

/* Pr_Mot_evnmt_mineur1 177-192 ********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut177[]= "017. Komunikat: AUTOMATYCZNA ZMIANA JEST NIEDOZWOLONA (wcisnij STARTING CHANGE, aby poznac szczegoly)   Rozpoczecie autom. sekwencji jest niedozwolone z powodu niespelnienia       niektorych wymaganych warunkow. Aby poznac szczegoly wcisnac STARTING CHANGE";
char far tbl_message_defaut178[]= "018. Komunikat: srednica nawinieta zbliza sie do maks. wartosci i TRYB ZMIANY WALU nie jest automat.    Zazadac recznej zmiany walu lub przelaczyc tryb na automatyczny albo,       w przypadku niespelnienia wymaganych warunkow, zatrzymac maszyne.           ";
char far tbl_message_defaut179[]= "019. Komunikat: Automatyczna zmiana walu wykonywana         (wcisnac przycisk F10, aby poznac szczegoly)Podczas zmiany walu maszyne mozna zatrzymac TYLKO przez wcisniecie          przycisku STOP MACHINE wiecej niz 5 razy (zalecana niska predkosc liniowa)  ";
char far tbl_message_defaut180[]= "020. Komunikat: AUTOMATYCZNA ZMIANA NIE JEST DOZWOLONA --> Brak nowego pustego walu                     Nie mozna rozpoczac sekwencji automatycznej zmiany.                         Pusty wal niedostepny i/lub nie jest wykryty przez przelaczniki zblizeniowe.";
char far tbl_message_defaut181[]= "021. Komunikat: AUTOMATYCZNA ZMIANA NIE JEST DOZWOLONA --> Predkosc maszyny zbyt mala                   Nie mozna rozpoczac sekwencji automatycznej zmiany.                         Biezaca predkosc odniesienia jest zbyt niska; zwieksz predkosc na linii.    ";
char far tbl_message_defaut182[]= "022. Komunikat: BRAK/UTRATA danych � Kalibracja dla kodera SSI ......                                   WAZNE: wykonac nowa kalibracje jak opisano w instrukcji uzytkownika maszyny i/lub skontaktowac sie z obsluga posprzedazowa.                             ";
char far tbl_message_defaut183[]= "023. Komunikat: Brak sygnalu gotowosci z napedow                                                        Oprogramowanie sterujace oczekuje na sygnal gotowosci z kazdego z napedow.  W przypadku problemow, otworzyc szafki i sprawdzic status napedow.          ";
char far tbl_message_defaut184[]= "024. Komunikat: BRAK NOWEGO PUSTEGO WALU                                                                Nie mozna rozpoczac sekwencji nowego walu.                                  Pusty wal nie jest dostepny i/lub niewykryty przez przelaczniki zblizeniowe.";
char far tbl_message_defaut185[]= "025. Komunikat: AUTOMATYCZNA ZMIANA NIE JEST DOZWOLONA --> Szybkosc maszyny zbyt duza                   Nie mozna rozpoczac sekwencji automatycznej zmiany.                         Biezaca predkosc odniesienia jest zbyt duza. Zmniejszyc predkosc linii.     ";
char far tbl_message_defaut186[]= "026. Komunikat: AUTOMATYCZNA ZMIANA NIE JEST DOZWOLONA --> Wykonywana jest sekwencja nowego walu        Nie mozna rozpoczac sekwencji automatycznej zmiany. Wykonywana jest funkcja nowego walu. Poczekaj na koniec lub zatrzymaj przyciskiem STOP MACHINE      ";
char far tbl_message_defaut187[]= "027. Komunikat: Zespol ciecia poprzecznego (GCT) nie jest w pozycji spoczynkowej              (CAN2.1.1)Zadane dzialanie niedozwolone. Przesunac obrotowy uklad splatania (ROT_SR), az zatrzyma sie w pozycji spoczynkowej i umiescic GCT z przodu przelacznika.";
char far tbl_message_defaut188[]= "028. Komunikat: Brak walu przy przesunieciu glownych wozkow (TRASL_CP)                        (CAN2.4.3)Zadane dzialanie nie jest dozwolone.                                        Umiescic wal na glownych wozkach i/lub sprawdzic odpowiednie wejscie.       ";
char far tbl_message_defaut189[]= "029. Komunikat: Ramiona opuszczania walu nie sa w pozycji roboczej (BRAS_MABF)                (CAN2.6.1)Zadane dzialanie nie jest dozwolone.                                        Otworzyc ramiona opuszczania walu i/lub sprawdzic odpowiednie wejscie.      ";
char far tbl_message_defaut190[]= "030. Komunikat: Wybrana srednica walu zbyt odbiega od srednicy 6-calowego walu                          Zadane dzialanie nie jest dozwolone. Otworzyc strone na ekranie sluzaca do  wydawania polecen ruchu glownych wozkow i wprowadzic poprawna srednice walu.";
char far tbl_message_defaut191[]= "031. Komunikat: UKLAD CIECIA (GCL) NIE JEST ZABLOKOWANY                                                 Zadane dzialanie nie jest dozwolone. Otworzyc strone na ekranie odpowiednia dla zespolu ciecia (GCL) i wcisnac przycisk "Lock Group"                    ";
char far tbl_message_defaut192[]= "032. Komunikat: OTWARTE DRZWI BEZPIECZEnSTWA LOW-SPEED                                                  Zadane dzialanie nie jest dozwolone.                                        Zamknac drzwi i/lub sprawdzic odpowiednie wejscia.                          ";

/* Pr_Mot_evnmt_mineur2 193-208 ********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut193[]= "033. Mess: CZEKAC NA MINIMALNA pozycje butli powietrznych na bebnie nawojowym #2     (ApplRP2)(CAN2.7.2)Sekwencja automatyczna czeka na osiagniecie brakujacego warunku.                                                                                        ";
char far tbl_message_defaut194[]= "034. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut195[]= "035. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut196[]= "036. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut197[]= "037. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut198[]= "038. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut199[]= "039. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut200[]= "040. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut201[]= "041. Mess: Miss REEL (or SHAFT) on the UNLOADING POSITION of the machine                      (CAN2.5.6)The requested action is not allowed. No Reel (or Shaft) is detected into theWINDER's unloading position. If necessary, check the correspondent input.   ";
char far tbl_message_defaut202[]= "042. Mess: The Vertical Position of the CRANE is TOO LOW   (the CRANE is too close to the Winder)       The requested action is not allowed. It is necessary to move UP the CRANE   using the correspondent manual command                                      ";
char far tbl_message_defaut203[]= "043. Mess: Miss Shaft LOADED on the MOTOR SIDE of the CRANE                                   (CAN3.7.3)The requested action is not allowed. A shaft must be present ONLY on the    MOTOR SIDE of the CRANE.If necessary,check the input showed into the message";
char far tbl_message_defaut204[]= "044. Mess: Miss REST POSITION (OPEN) of the CRANE's ROTATIONAL ARM                            (CAN3.7.2)The requested action is not allowed. Turn the ROTATIONAL ARM into its REST  POSITION using the manual command or check the input showed into the message";
char far tbl_message_defaut205[]= "045. Mess: Reel LOADED on the TRANSLATION TABLE                                               (CAN1.5.6)The requested action is not allowed. Remove the reel present on the         Translation Table and/or check the inputs indicated into the message.       ";
char far tbl_message_defaut206[]= "046. Mess: Shaft LOADED on the CRANE                                   (CAN3.1.3 or CAN3.7.3 - CAN3.7.4)The requested action is not allowed. Remove the shaft that has been loaded  on the Crane or check the inputs indicated into the message.                ";
char far tbl_message_defaut207[]= "047. Mess: Shaft Inflating Timer NOT ENDED                                                              The requested action is not allowed. A Shaft Inflating Command is executing.Wait for the end of the correspondent timer (15sec).                        ";
char far tbl_message_defaut208[]= "048. Mess: Miss REST POSITION of the CRANE's PIN                                              (CAN3.8.4)The requested action is not allowed. Move the PIN into its REST POSITION    using the manual command or check the input indicated into the message.     ";

/* Pr_Mot_evnmt_mineur3 209-224 ********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut209[]= "049. Mess: The CRANE's Pliers have not been INFLATED                                                    The requested action is not allowed.                                        Inflate the Pliers using the correspondent manual command.                  ";
char far tbl_message_defaut210[]= "050. Mess: The CRANE's Pliers have not been DEFLATED                                                    The requested action is not allowed.                                        Deflate the Pliers using the correspondent manual command.                  ";
char far tbl_message_defaut211[]= "051. Mess: REACHED MIN(OPEN) or MAX(CLOSED) Position of CRANE's ROTATIONAL ARM    (CAN3.7.1 or CAN3.7.2)The requested action is not allowed. The ROTATIONAL ARM reached one of its  limit position. If necessary, check the inputs indicated into the message.  ";
char far tbl_message_defaut212[]= "052. Mess: Miss REST (CLOSED) POSITION of the CRANE's PLIERS GROUP                            (CAN3.7.6)The requested action is not allowed. Move the Pliers Group into its resting position using the correspondent manual command or check the indicated input";
char far tbl_message_defaut213[]= "053. Mess: Miss WORK (CLOSED) POSITION of the CRANE's VICE                                    (CAN3.8.1)The requested action is not allowed. Close the Vice using the correspondent manual command or check the input indicated into the message.               ";
char far tbl_message_defaut214[]= "054. Mess: The movement of the CRANE's ROTATIONAL ARM in NOT ENABLED                                    The requested action is not allowed. The manual rotation of the Crane's Arm is enabled ONLY after the unloading of a reel on the Translation Table.     ";
char far tbl_message_defaut215[]= "055. Mess: Miss TRANSLATION TABLE's LIMIT POSITIONS                                (CAN1.5.4 - CAN1.5.5)The requested action is not allowed. Move manually the TRANSLATION TABLE to one of its limit (IN or OUT) positions or check the indicated inputs.       ";
char far tbl_message_defaut216[]= "056. Mess: The Horizontal Position of the CRANE is NOT COMPATIBLE with the requested action             The requested action is not allowed. Move forward/backward the Crane either to the Shaft-Unloading or Reel-Loading or Reel-Unloading position.          ";
char far tbl_message_defaut217[]= "057. Mess: The CRANE has REACHED its MINIMUM VERTICAL LIMIT                                             The requested action is not allowed. The downward movement of the Crane has been DISABLED according to its horizontal position.                         ";
char far tbl_message_defaut218[]= "058. Mess: The CRANE has REACHED its MINIMUM or MAXIMUM HORIZONTAL LIMIT          (CAN3.5.2 or CAN3.5.3)The requested action is not allowed. The CRANE reached one of its HORIZONTALlimit. If necessary, check the inputs indicated into the message.           ";
char far tbl_message_defaut219[]= "059. Mess: Miss CRANE's MAXIMUM VERTICAL POSITION                                             (CAN3.6.3)The requested action is not allowed. Move upward the CRANE until its MAXIMUMVERTICAL position or check the input indicated into the message.            ";
char far tbl_message_defaut220[]= "060. Mess: Miss REST POSITION of the CRANE's PIN                                              (CAN3.8.4)The requested action is not allowed. Move the PIN into its REST POSITION    using the manual command or check the input indicated into the message.     ";
char far tbl_message_defaut221[]= "061. Mess: Miss WORK (OPEN) POSITION of the CRANE's PLIERS GROUP                              (CAN3.7.5)The requested action is not allowed. Move the Pliers Group into its working position using the correspondent manual command or check the indicated input";
char far tbl_message_defaut222[]= "062. Mess: Miss REST (OPEN) POSITION of the CRANE's VICE                                      (CAN3.8.2)The requested action is not allowed. Open the VICE using the correspondent  manual command or check the input indicated into the message.               ";
char far tbl_message_defaut223[]= "063. Mess: Miss WORK (CLOSED) POSITION of the CRANE's ROTATIONAL ARM                          (CAN3.7.1)The requested action is not allowed. Close the ROTATIONAL using the relativemanual command or check the input indicated into the message.               ";
char far tbl_message_defaut224[]= "064. Mess: CRANE RUNNING                                                                                The requested action is not allowed. The Crane is still running following a manual request of movement. Stop the previous command to execute the new one";

/* Pr_Mot_evnmt_mineur4 225-240 ********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut225[]= "065. Komunikat: Przemieszczenie glownych wozkow nie jest w pozycji maksymalnej (TRASL_CP)     (CAN2.4.5)Zadane dzialanie nie jest dozwolone.                                        Przesunac wozki do gory do ich maksymalnego polozenia lub sprawdzic wejscie.";
char far tbl_message_defaut226[]= "066. Komunikat: Przemieszczenie glownych wozkow (TRASL_CP) w maksymalnym polozeniu            (CAN2.4.5)Zadane dzialanie nie jest dozwolone.                                        Przesunac wozki w dol z ich polozenia maksymalnego lub sprawdzic wejscie.   ";
char far tbl_message_defaut227[]= "067. Komunikat: Ramiona opuszczania walu nie sa w polozeniu spoczynkowym (BRAS_MABF)          (CAN2.6.2)Zadane dzialanie nie jest dozwolone.                                        Przesunac urzadzenie do gory do polozenia spoczynk. lub sprawdzic wejscie.  ";
char far tbl_message_defaut228[]= "068. Komunikat: Wal jest na ramionach opuszczania walu (BRAS_MABF)                            (CAN2.6.3)Zadane dzialanie nie jest dozwolone.                                        Zdjac wal z ramion opuszczania walu lub sprawdzic wejscie.                  ";
char far tbl_message_defaut229[]= "069. Komunikat: Wal jest na glownych wozkach przemieszczenia (TRASL_CP)                       (CAN2.4.3)Zadane dzialanie nie jest dozwolone.                                        Zdjac wal z glownych wozkow lub sprawdzic wejscie.                          ";
char far tbl_message_defaut230[]= "070. Komunikat: OTWARTE DRZWI BEZPIECZEnSTWA                                                            Zadane dzialanie nie jest dozwolone.                                        Zamknac drzwi i/lub sprawdzic odpowiednie wejscia                           ";
char far tbl_message_defaut231[]= "071. Komunikat: Obrot glownych wozkow nie jest w min. lub maks. polozeniu (ROT_CP) (CAN2.3.4 - CAN2.3.3)Zadane dzialanie nie jest dozwolone.                                        Obrocic glowne wozki do ich minimalnego lub maksymalnego polozenia.         ";
char far tbl_message_defaut232[]= "072. Komunikat: Szczypce na gl. wozkach nie sa w polozeniu odblokowanym (LOCK_CP)  (CAN2.3.6 - CAN2.4.2)Zadane dzialanie nie jest dozwolone.                                        Odblokowac szczypce na gl. wozkach (CP) lub sprawdzic odpowiednie wejscia.  ";
char far tbl_message_defaut233[]= "073. Komunikat: Przesuniecie pomocniczych wozkow nie jest w strefie bezpieczenstwa (TRASL_CS)           Zadane dzialanie nie jest dozwolone, poniewaz wozki pomocnicze sa zbyt   blisko bebna nawijania 1. Przesunac je do przodu do ich strefy bezpieczenstwa. ";
char far tbl_message_defaut234[]= "074. Komunikat: Obrot ukl. splatania poza strefie oczekiwania (lub w pol. spocz.) (ROT_SR)    (CAN2.5.4)Zadane dzialanie nie jest dozwolone, poniewaz uklad splatania jest poza     strefa spoczynkowa. Obrocic az do automatycznego zatrzymania w tej strefie. ";
char far tbl_message_defaut235[]= "075. Komunikat: Zasilanie powietrzem ukladu splatania nie jest w pozycji spoczynkowej (AIR_SR)(CAN2.1.5)Zadane dzialanie nie jest dozwolone.                                        Przesunac urzadzenie z powrotem do pol. spoczynk. albo sprawdzic wejscie.   ";
char far tbl_message_defaut236[]= "076. Komunikat: Osiagnieto min. lub maks. polozenie obrotu glownych wozkow (CP)    (CAN2.3.3 - CAN2.3.4)Zadane dzialanie nie jest dozwolone.                                        Glowne wozki osiagnely jedno ze swoich granicznych polozen.                 ";
char far tbl_message_defaut237[]= "077. Komunikat: Blad, magnetyczny przelacznik temp. silnika obrotu glownych wozkow (ROT_CP)   (CAN1.3.3)Aktualne przeciazenie odpowiedniego silnika. Sprawdzic przyczyny, wlaczyc   ponownie urzadzenie w szafce lub sprawdzic wejscie.                         ";
char far tbl_message_defaut238[]= "078. Komunikat: Blad, magn. przelacznik temperaturowy hamulca silnika obrotu glownych wozkow  (CAN1.3.2)Aktualne przeciazenie odpowiedniego silnika. Sprawdzic przyczyny, wlaczyc   ponownie urzadzenie w szafce lub sprawdzic wejscie.                         ";
char far tbl_message_defaut239[]= "079. Komunikat: Blad, magnetyczny przelacznik temp. hamulca silnika obrotu ukladu splatania   (CAN1.3.1)Aktualne przeciazenie hamulca odpowiedniego silnika. Sprawdzic przyczyny,   wlaczyc ponownie urzadzenie w szafce lub sprawdzic wejscie.                 ";
char far tbl_message_defaut240[]= "080. Komunikat: Jedno polecenie dla urzadzenia w zespole ciecia poprzecznego jest ciagle aktywne (GCT)  Zadane dzialanie nie jest dozwolone.                                        Zatrzymac, usunac aktywne polecenie lub poczekac, az zostanie ono zakonczone";

/* Pr_Mot_Def_grave8 241-256*************************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut241[]= "DG113. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut242[]= "DG114. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut243[]= "DG115. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut244[]= "DG116. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut245[]= "DG117. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut246[]= "DG118. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut247[]= "DG119. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut248[]= "DG120. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut249[]= "DG121. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut250[]= "DG122. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut251[]= "DG123. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut252[]= "DG124. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut253[]= "DG125. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut254[]= "DG126. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut255[]= "DG127. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut256[]= "DG128. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_Def_simple4 257-272 **********************************************************************************/                          */
/***************************************************************************************************************/                          */
char far tbl_message_defaut257[]= "DS049. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut258[]= "DS050. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut259[]= "DS051. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut260[]= "DS052. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut261[]= "DS053. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut262[]= "DS054. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut263[]= "DS055. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut264[]= "DS056. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut265[]= "DS057. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut266[]= "DS058. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut267[]= "DS059. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut268[]= "DS060. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut269[]= "DS061. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut270[]= "DS062. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut271[]= "DS063. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut272[]= "DS064. ...                                                                                              (Niewykorzystany)                                                                                                                                       ";

/* Pr_Mot_evnmt_mineur5 273-288 ********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut273[]= "081. Komunikat: Czekaj na strefe robocza (lub polozenie robocze) obrotu ukladu ciecia (ROT_SR)(CAN2.5.4)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut274[]= "082. Komunikat: Czekaj na strefe oczekiwania (lub polozenie spocz.) obr. ukl. ciecia (ROT_SR) (CAN2.5.4)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut275[]= "083. Komunikat: Czekaj na maksymalne polozenie obrotu glownych wozkow (ROT_CP)                (CAN2.3.3)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut276[]= "084. Komunikat: Czekaj na maksymalne polozenie obrotu glownych wozkow (ROT_CP)                (CAN2.3.4)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut277[]= "085. Komunikat: Czekaj na przejscie walu do polozenia rozladowania                            (CAN2.5.6)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut278[]= "086. Komunikat: Czekaj na polozenie ciecia z przesuniecia glownych wozkow (TRASL_CP)          (CAN2.4.6)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut279[]= "087. Komunikat: Szczypce w wozkach gl. nie sa w polozeniu zablokowanym (LOCK_CP)   (CAN2.3.5 - CAN2.4.1)Zadane dzialanie nie jest dozwolone.                                        Zablokowac szczypce w gl. wozkach (CP) lub sprawdzic odpowiednie wejscia.   ";
char far tbl_message_defaut280[]= "088. Komunikat: Zasilanie powietrzem ukladu splatania nie jest zalozone (AIR_SR)                        Zadane dzialanie nie jest dozwolone.                                        Przesunac urzadzenie do przodu z jego pozycji spocz.lub sprawdzic wejscie   ";
char far tbl_message_defaut281[]= "089. Komunikat: Poziome polozenie przesuniecia wozkow pomocniczych (TRASL_CS) jest zbyt duze            Zadane dzialanie nie jest dozwolone.                                        Przesunac urzadzenie do tylu, aby usunac je ze strefy odwijania rolki.      ";
char far tbl_message_defaut282[]= "090. Komunikat: Przesuniecie gl. wozkow (TRASL_CP) nie jest w pol. spocz. lub ciecia (CAN2.4.4 CAN2.4.6)Zadane dzialanie nie jest dozwolone. Przesunac gl. wozki do dolu, aby osiagnelyswoje polozenie spoczynkowe (minimalne) lub do ciecia (rozladowanie walu)";
char far tbl_message_defaut283[]= "091. Komunikat: Ramiona opuszczania walu nie sa w polozeniu roboczym (otwarte) (BRAS_MABF)    (CAN2.6.1)Zadane dzialanie nie jest dozwolone. Przesunac w dol (lub otworzyc) ramiona opuszczania walu,az osiagna polozenie robocze (min) lub sprawdzic wejscie   ";
char far tbl_message_defaut284[]= "092. Komunikat: Obrot ukl. ciecia nie jest w polozeniu oczekiwania (spocz.) lub bezpiecz.     (CAN2.5.4)Zadane dzialanie nie jest dozwolone. Aby wykonac zadana operacje, przesunac SR do polozenia spoczynkowego albo do polozenia bezpieczenstwa.             ";
char far tbl_message_defaut285[]= "093. Komunikat: Nie usunieto przylozenia wozkow pomocniczych (APPL_CS)                                  Zadane dzialanie nie jest dozwolone.                                                                                                                    ";
char far tbl_message_defaut286[]= "094. Komunikat: Czekaj na przyspieszenie obrotu bebna nawijania 1 (ROT_RP1)                             Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut287[]= "095. Komunikat: Hamulec walu w strefie rozladowania nie jest w pozycji spoczynkowej (otwarty) (CAN2.5.5)Zadane dzialanie nie jest dozwolone lub automatyczna sekwencja oczekuje na spelnienie warunku.Otworzyc urzadzenie do przelaczenia albo sprawdzic wejscie";
char far tbl_message_defaut288[]= "096. Komunikat: Wal jest w pozycji rozladowania                                               (CAN2.5.6)Zadane dzialanie nie jest dozwolone lub automatyczna sekwencja oczekuje na  spelnienie warunku. Zdjac wal lub sprawdzic wejscie.                        ";

/* Pr_Mot_evnmt_mineur6 289-304 ********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut289[]= "097. Komunikat: Czekaj az szczypce w glownych wozkach sie zablokuja (LOCK_CP)      (CAN2.3.5 - CAN2.4.1)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut290[]= "098. Komunikat: Czekaj az szczypce w glownych wozkach sie odblokuja (LOCK_CP)      (CAN2.3.6 - CAN2.4.2)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut291[]= "099. Komunikat: Czekaj na zadanie recznego rozpoczecia                                                  Automatyczna sekwencja zatrzymana. Wcisnij STARTING CHANGE, aby kontynuowac sekwencje lub wlacz tryb auto przyciskiem MODE CHANGE (zmiana trybu).       ";
char far tbl_message_defaut292[]= "100. Komunikat: Czekaj az przesuniecie glownych wozkow osiagnie maks. polozenie (TRASL_CP)    (CAN2.4.5)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut293[]= "101. Komunikat: Czekaj az przesuniecie glownych wozkow osiagnie min. polozenie (TRASL_CP)     (CAN2.4.4)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut294[]= "102. Komunikat: Czekaj az krzywki parkowania walow znajda sie w pozycji roboczej (CAM_MABF)   (CAN2.6.4)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut295[]= "103. Komunikat: Czekaj az krzywki beda w pol. spocz. i wal w miejscu parkowania    (CAN2.6.5 - CAN2.6.3)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut296[]= "104. Komunikat: Czekaj az ramiona opuszczania walu znajda sie w polozeniu spocz.  (BRAS_MABF) (CAN2.6.2)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut297[]= "105. Komunikat: Czekaj az ramiona opuszcz. beda w p. roboczym i bedzie w nich wal  (CAN2.6.1 - CAN2.6.3)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut298[]= "106. Komunikat: Czekaj az naped osi centr. w gl. wozku (ENG_CP) bedzie w p. roboczym (wl.)    (CAN2.5.2)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut299[]= "107. Komunikat: Czekaj az naped osi centr. w gl. wozku (ENG_CP) bedzie w pol. spocz. (wyl)    (CAN2.5.3)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut300[]= "108. Komunikat: Czekaj na przyspieszenie walu                                                           Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut301[]= "109. Komunikat: Czekaj az zasilanie w powietrze ukladu splatania (AIR_SR) bedzie w polozeniu roboczym   Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut302[]= "110. Komunikat: Czekaj az zasilanie pow. ukl. splat. (AIR_SR) bedzie w p. spocz.              (CAN2.1.5)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut303[]= "111. Komunikat: Czekaj az szczypce w wozkach pomocn. beda w p. zablok. (LOCK_CS)   (CAN2.2.1 - CAN2.2.3)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut304[]= "112. Komunikat: Czekaj az szczypce w wozkach pomocn. beda w p. odblok. (LOCK_CS)   (CAN2.2.2 - CAN2.2.4)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";

/* Pr_Mot_evnmt_majeur2 305-320 ********************************************************************************/
/***************************************************************************************************************/
char far tbl_message_defaut305[]= "113. Komunikat: Nawinieta (lub wykryta) srednica przekracza maks. dopuszczalna wartosc dla tej maszyny  Zadane dzialanie nie jest dozwolone. Rozpoczac na nowym wale lub sprawdzic  potencjometr sluzacy do obliczania srednicy rolki.                          ";
char far tbl_message_defaut306[]= "114. Komunikat: Nawinieta (lub wykryta) srednica jest wieksza niz zadana wartosc powodujaca zatrzymanie.Zadane dzialanie niedozwolone. Zmienic zadana wartosc zatrzymania,rozpoczacprace na nowym wale lub sprawdzic potencjometr sluzacy do obliczania srednicy";
char far tbl_message_defaut307[]= "115. Komunikat: Nawinieta dlugosc jest wieksza, niz zadana wartosc powodujaca zatrzymanie.              Zadane dzialanie nie jest dozwolone. Zmienic zadana wartosc powodujaca zatrzymanie lub wyzerowac licznik na stronie STOP SETTING(ustawienia zatrzymania)";
char far tbl_message_defaut308[]= "116. Komunikat: BRAK MINIMALNEJ pozycji butli powietrznych na bebnie nawojowym #2 (ApplRP2)   (CAN2.1.2)Zadana czynnosc jest niedozwolona. PRZESUN beben nawojowy #2 do jego pozycjiMINIMALNEJ lub sprawdz odpowiednie wejscie cyfrowe (parametr cyfrowy).      ";
char far tbl_message_defaut295[]= "117. Komunikat: Czekaj az krzywki beda w pol. spocz. i wal w miejscu parkowania    (CAN2.6.5 - CAN2.4.3)Automatyczna sekwencja oczekuje na spelnienie brakujacego warunku.                                                                                      ";
char far tbl_message_defaut310[]= "118. Komunikat: BRAK MAKSYMALNEJ (ROBOCZEJ) pozycji KRZYWEK na parkingu walow (CAM_MABF)      (CAN2.6.4)Zadana czynnosc jest niedozwolona. PRZESUN KRZYWKI do GORY do pozycji MAKSYMALNEJ Ustaw lub sprawdz odpowiednie wejscie cyfrowe wskazane w komunikacie. ";
char far tbl_message_defaut311[]= "119. Mess: FAST STOP REQUESTED                                                                (CAN1.1.3)The Fast-Stop pushbutton has been pressed.                                                                                                              ";
char far tbl_message_defaut312[]= "120. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut313[]= "121. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut314[]= "122. Mess: ...                                                                                          (Niewykorzystany)                                                                                                                                       ";
char far tbl_message_defaut315[]= "123. Mess: A CRANE's Automatic sequence is RUNNING (REEL --> UNLOAD POSITION)                           It's not possible to start the Automatic Change Sequence. Wait for the end  of this or stop it pressing the STOP pushbutton into the CRANE CONTROL page ";
char far tbl_message_defaut316[]= "124. Mess: The Horizontal Position of the CRANE is TOO LOW (the CRANE is too close to the Winder)       It's not possible to start the Automatic Change Sequence. It is necessary tomove FORWARD the CRANE using the correspondent manual command               ";
char far tbl_message_defaut317[]= "125. Mess: The Vertical Position of the CRANE is TOO LOW   (the CRANE is too close to the Winder)       It's not possible to start the Automatic Change Sequence. It is necessary tomove UP the CRANE using the correspondent manual command                    ";
char far tbl_message_defaut318[]= "126. Mess: A CRANE's Automatic sequence is RUNNING                                                      The requested action is not allowed. Wait for the end of the sequence or    stop it pressing the corresponding pushbutton into the CRANE CONTROL page   ";
char far tbl_message_defaut319[]= "127. Mess: The Execution of the CRANE's Automatic Sequence has been STOPPED                             The sequence has been stopped due to an ALARM CONDITION or following the    selection of the STOP pushbutton inside the CRANE CONTROL page              ";
char far tbl_message_defaut320[]= "128. Mess: The Execution of the CRANE's Automatic Sequence has been PAUSED                              Select the pushbuttons CONTINUE or STOP inside the CRANE CONTROL page       to continue or to terminate definitively the execution of the function      ";

/* char * tbl_aff_mode_machine[] = {*/
                                    " -  AUTOMAT  - ",
                     	            "  - Tryb  0 -  ",
                                    "- ReCZN. STOP -",
                                    "- ReCZN. TRYB -",
                                    "- KONSERWACJA -",
                                    "- TEST SILNIK -",
                                    "  - PRZEPIS -  ",

/* char * tbl_aff_etat_machine[] = {*/
				                    "  Stop Awaria  ",
				                    "Wymagane Zasil.",
				                    " Stop-Normalny ",
				                    "  Wlacz reczny ",
				                    " Wlacz syrene  ",
				                    " Starting Wait ",
				                    "  Rozpoczecie  ",
				                    " Wykonywanie   ",
				                    " Zak. oczekiw. ",
				                    "  Zatrzymanie  ",
				                    "  Awaria Wlacz ",
				                    " Zatrz. ham. WL",

/* char *label_bobine[] */
                                    "Srednica        ",
                                    "Dlugosc         ",
                                    "Waga            ",
                                    "Godzina zakoncz.",
                                    "Czas do zakoncz.",
                                    "Godzina rozpocz.",
                                    "OSTATNIA ROLKA  ",
                                    "ROLKA ROBOCZA:  ",

/* char *label_divers[] */
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									"--------",
									
/* char *label_txts[] */
									"SZYBKOSCI:     ",
									"Wartosc wejsc. ",
									"Gl. wal (RP1)  ",
									"NACIAG:        ",
									"Naciag docelowy",
									"Cisn. (Prowad) ",
									"Naciag wejsc.  ",
									"               ",
									"               ",
									"               ",
									"               ",
									"               ",
									"               ",
									"               ",
									"               ",

/* char *label_buttons[] */
									"   START     ",
									"  MASZYNA    ",
									"   [F13]     ",
									"   STOP      ",
									"  MASZYNA    ",
									"   [F14]     ",
									" RP1 PRZD    ",
									" RP1 TYL     ",
									" DEP PRZD    ",
									" DEP TYL     ",
									" REM PRZD    ",
									" REM TYL     ",
									" TST LAMP    ",
									"  ROZPOCZ.   ",
									"   ZMIANA    ",
									"    [F3]     ",
									"  NACISNAC,  ",
									" DLA WARUNKI ",
									"  KONIECZNE  ",
									"             ",
									"             ",
									"    [F3]     ",
									"  NOWY  WAL  ",
									
/* char *label_buttons_mode[] *
									"TRYB MASZYNY RECZNY    [F1]",
									"TRYB MASZYNY AUTOMAT.  [F1]",
									"ZMIANA TRYBU RECZNY    [F2]",
 									"ZMIANA TRYBU AUTOMAT.  [F2]",

/* char *tbl_text_setting_parameter[] */
								    " NACIAG PROWADN.             ",
									" SILA RAMION POMOCN.         ",
									" USLIZG SZYBKOSCI RP1        ",
									" RP2's OUTPUT PRESSURE       ",

/* char *tbl_choix_curve_type[] */
                                    "         Linia  ",
                                    " Parabolic #1 + ",
                                    " Parabolic #2 + ",
                                    " Parabolic #1 - ",
                                    " Parabolic #2 - ",
                                    "     Hyperbolic ",
                                    " Graf. linia    ",
                                    
/* char *tbl_choix_options[] */
                                    "  NIE",
                                    "  TAK",

/* char *tbl_choix_status[] */
                                    " WYLACZ.",
                                    "WLACZONE",
				                    "........",

/* char * tbl_aff_phase_automatic[] */
									" MARCHE ",
									" ZMIANA ",

/* char * tbl_aff_mode_status[] = */
                                    "Urzadz. PRACUJA",
                                    "Urzadz. ZATRZYM",
                                    "   NOWY WAL    ",
                                    "    MARCHE     ",
                                    "  ZMIANA WALU  ",

/* char *tbl_choix_RP2_mode[] */
                                    "........",
                                    "........",

/* char *tbl_text_RP2_mode[] */
                                    "...............",
                                    "...............",

/* char *tbl_aff_etat_receipe[] */
                                    "** BRAK przepisu w pamieci **",
                                    "***Odczyt wybranego przep.***",
                                    "***Zapisano wybrany przep.***",

/* char *tbl_err_memo[] */
                                    " Brak bledu!                    ",
                                    " Blad rozmiar pliku!            ",
                                    " Plik lub dysk nie istnieje!    ",
									" Dysk jest pelen !              ",

/* char *tbl_text_selected_PID[] */								
                                    "PID REGULACJA NACIAGU ",
                                    "PID WAL WEJSCIOWY     ",
                                    "PID on APPLICATION RP2",
                                    
/* char *tbl_txt_SpeedCorrection[] */
		                            "                             ",
			                    	" Korekc.Szybkosci[%/s]       ",
			                        " Pressure Corr. [%/s]        ",

/* char *tbl_choix_raison_saisie_code[] */
                                    "  Menu TRYBU KONSERWACJI",
                                    "Str. USTAWIEn PARAMETRoW",               
                                    "Str USTAWIEn STEROWNIKoW",
                                    "STRONA WLACZENIA WYGLADZ",
                                    "         Strona PRZEPISY",
                                    "      Strona DEBUGOWANIE",
                                    "     Strona TEST WEJsCIA",
                                    "     Strona TEST WYJsCIA",
                                    "         Strona TEST OSI",
                                    "Strona TEST WYJ. ANALOG.",
                                    "   Strona KALIBRACJA SSI",
                                    "          Strona POZYCJE",
                                    "    Strona POTENCJOMETRY",
                                    " Strona MENU DEBUGOWANIA",
                                    
/* char *tbl_choix_format_date[] */
									" DZIEN-MIES-ROK  ",
									" MIES-DZIEN-ROK  ",

/* char *label_button_modeControl[] */
                                   "                               ",
                                   " (WAL 3'') STEROWANIE WLACZONE ",
                                   "(WAL 3'')STEROWANIE NIEWLACZONE",
                                   "(WAL 6'')STEROWANIE NIEWLACZONE",
                                    
/* char *label_actual_output[] */
                                   "                   ",
                                   "Bie.WartoscKrzywej:",
                                   "Biezaca Korekcja  :",

/* char *tbl_choix_source[] */
									"   PAMIEC",
									"   FLOPPY",
									"GNIAZ.USB",

/* char *tbl_default_name[] */
									"(Wprowadz kod klawiszem Enter)    ",
									"..................................",

/* char *str_LoadCells[] */
									"   Wprowadzic KOREKCJE celu ruchu [%]:",
                                    "     Wprowadzic STALA celu ruchu [Nw]:",
									"                                      ",
                                    
/* char *label_button_crane[] */
									"  CRANE      ",
									" CONTROL     ",
									"   [+]       ",

/* char *label_button_modeCrane[] */
									"  CRANE CONTROL MODE:  NOT ENABLED  ",
									"      CRANE CONTROL MODE: TEST      ",
									"     CRANE CONTROL MODE: MANUAL     ",
									"   CRANE CONTROL MODE:  AUTOMATIC   ",
									"                [F1]                ",


                                    