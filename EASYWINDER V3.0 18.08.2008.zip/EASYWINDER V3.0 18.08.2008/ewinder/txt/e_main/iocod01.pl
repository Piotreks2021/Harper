/* Table of the inputs                                   */
/* char *tbl_input[] =                                   */
/*                            123456789012345678901234567*/
char far tbl_input00[]     = "                           ";

/* INPUT CARD: 32IN1  **/
/***********************/
char far tbl_input_1_1_1[] = "1.0                        ",
char far tbl_input_1_1_2[] = "1.1                        ",
char far tbl_input_1_1_3[] = "1.2                        ",
char far tbl_input_1_1_4[] = "1.3                        ",
char far tbl_input_1_1_5[] = "1.4                        ",
char far tbl_input_1_1_6[] = "1.5                        ",
char far tbl_input_1_1_7[] = "1.6                        ",
char far tbl_input_1_1_8[] = "1.7                        ",

char far tbl_input_1_2_1[] = "2.0                        ",
char far tbl_input_1_2_2[] = "2.1                        ",
char far tbl_input_1_2_3[] = "2.2                        ",
char far tbl_input_1_2_4[] = "2.3                        ",
char far tbl_input_1_2_5[] = "2.4                        ",
char far tbl_input_1_2_6[] = "2.5                        ",
char far tbl_input_1_2_7[] = "2.6                        ",
char far tbl_input_1_2_8[] = "2.7                        ",

char far tbl_input_1_3_1[] = "3.0                        ",
char far tbl_input_1_3_2[] = "3.1                        ",
char far tbl_input_1_3_3[] = "3.2                        ",
char far tbl_input_1_3_4[] = "3.3                        ",
char far tbl_input_1_3_5[] = "3.4                        ",
char far tbl_input_1_3_6[] = "3.5                        ",
char far tbl_input_1_3_7[] = "3.6                        ",
char far tbl_input_1_3_8[] = "3.7                        ",

char far tbl_input_1_4_1[] = "4.0                        ",
char far tbl_input_1_4_2[] = "4.1                        ",
char far tbl_input_1_4_3[] = "4.2                        ",
char far tbl_input_1_4_4[] = "4.3                        ",
char far tbl_input_1_4_5[] = "4.4                        ",
char far tbl_input_1_4_6[] = "4.5                        ",
char far tbl_input_1_4_7[] = "4.6                        ",
char far tbl_input_1_4_8[] = "4.7                        ",


/* INPUT CARD: 32IN2  **/
/***********************/
char far tbl_input_2_1_1[] = "1.0                        ",
char far tbl_input_2_1_2[] = "1.1                        ",
char far tbl_input_2_1_3[] = "1.2                        ",
char far tbl_input_2_1_4[] = "1.3                        ",
char far tbl_input_2_1_5[] = "1.4                        ",
char far tbl_input_2_1_6[] = "1.5                        ",
char far tbl_input_2_1_7[] = "1.6                        ",
char far tbl_input_2_1_8[] = "1.7                        ",

char far tbl_input_2_2_1[] = "2.0                        ",
char far tbl_input_2_2_2[] = "2.1                        ",
char far tbl_input_2_2_3[] = "2.2                        ",
char far tbl_input_2_2_4[] = "2.3                        ",
char far tbl_input_2_2_5[] = "2.4                        ",
char far tbl_input_2_2_6[] = "2.5                        ",
char far tbl_input_2_2_7[] = "2.6                        ",
char far tbl_input_2_2_8[] = "2.7                        ",

char far tbl_input_2_3_1[] = "3.0                        ",
char far tbl_input_2_3_2[] = "3.1                        ",
char far tbl_input_2_3_3[] = "3.2                        ",
char far tbl_input_2_3_4[] = "3.3                        ",
char far tbl_input_2_3_5[] = "3.4                        ",
char far tbl_input_2_3_6[] = "3.5                        ",
char far tbl_input_2_3_7[] = "3.6                        ",
char far tbl_input_2_3_8[] = "3.7                        ",

char far tbl_input_2_4_1[] = "4.0                        ",
char far tbl_input_2_4_2[] = "4.1                        ",
char far tbl_input_2_4_3[] = "4.2                        ",
char far tbl_input_2_4_4[] = "4.3                        ",
char far tbl_input_2_4_5[] = "4.4                        ",
char far tbl_input_2_4_6[] = "4.5                        ",
char far tbl_input_2_4_7[] = "4.6                        ",
char far tbl_input_2_4_8[] = "4.7                        ",


/* INPUT CARD: 32IN3  **/
/***********************/
char far tbl_input_3_1_1[] = "1.0                        ",
char far tbl_input_3_1_2[] = "1.1                        ",
char far tbl_input_3_1_3[] = "1.2                        ",
char far tbl_input_3_1_4[] = "1.3                        ",
char far tbl_input_3_1_5[] = "1.4                        ",
char far tbl_input_3_1_6[] = "1.5                        ",
char far tbl_input_3_1_7[] = "1.6                        ",
char far tbl_input_3_1_8[] = "1.7                        ",

char far tbl_input_3_2_1[] = "2.0                        ",
char far tbl_input_3_2_2[] = "2.1                        ",
char far tbl_input_3_2_3[] = "2.2                        ",
char far tbl_input_3_2_4[] = "2.3                        ",
char far tbl_input_3_2_5[] = "2.4                        ",
char far tbl_input_3_2_6[] = "2.5                        ",
char far tbl_input_3_2_7[] = "2.6                        ",
char far tbl_input_3_2_8[] = "2.7                        ",

char far tbl_input_3_3_1[] = "3.0                        ",
char far tbl_input_3_3_2[] = "3.1                        ",
char far tbl_input_3_3_3[] = "3.2                        ",
char far tbl_input_3_3_4[] = "3.3                        ",
char far tbl_input_3_3_5[] = "3.4                        ",
char far tbl_input_3_3_6[] = "3.5                        ",
char far tbl_input_3_3_7[] = "3.6                        ",
char far tbl_input_3_3_8[] = "3.7                        ",

char far tbl_input_3_4_1[] = "4.0                        ",
char far tbl_input_3_4_2[] = "4.1                        ",
char far tbl_input_3_4_3[] = "4.2                        ",
char far tbl_input_3_4_4[] = "4.3                        ",
char far tbl_input_3_4_5[] = "4.4                        ",
char far tbl_input_3_4_6[] = "4.5                        ",
char far tbl_input_3_4_7[] = "4.6                        ",
char far tbl_input_3_4_8[] = "4.7                        ",


/* INPUT CARD: 32IN4  **/
/***********************/
char far tbl_input_4_1_1[] = "1.0                        ",
char far tbl_input_4_1_2[] = "1.1                        ",
char far tbl_input_4_1_3[] = "1.2                        ",
char far tbl_input_4_1_4[] = "1.3                        ",
char far tbl_input_4_1_5[] = "1.4                        ",
char far tbl_input_4_1_6[] = "1.5                        ",
char far tbl_input_4_1_7[] = "1.6                        ",
char far tbl_input_4_1_8[] = "1.7                        ",

char far tbl_input_4_2_1[] = "2.0                        ",
char far tbl_input_4_2_2[] = "2.1                        ",
char far tbl_input_4_2_3[] = "2.2                        ",
char far tbl_input_4_2_4[] = "2.3                        ",
char far tbl_input_4_2_5[] = "2.4                        ",
char far tbl_input_4_2_6[] = "2.5                        ",
char far tbl_input_4_2_7[] = "2.6                        ",
char far tbl_input_4_2_8[] = "2.7                        ",

char far tbl_input_4_3_1[] = "3.0                        ",
char far tbl_input_4_3_2[] = "3.1                        ",
char far tbl_input_4_3_3[] = "3.2                        ",
char far tbl_input_4_3_4[] = "3.3                        ",
char far tbl_input_4_3_5[] = "3.4                        ",
char far tbl_input_4_3_6[] = "3.5                        ",
char far tbl_input_4_3_7[] = "3.6                        ",
char far tbl_input_4_3_8[] = "3.7                        ",

char far tbl_input_4_4_1[] = "4.0                        ",
char far tbl_input_4_4_2[] = "4.1                        ",
char far tbl_input_4_4_3[] = "4.2                        ",
char far tbl_input_4_4_4[] = "4.3                        ",
char far tbl_input_4_4_5[] = "4.4                        ",
char far tbl_input_4_4_6[] = "4.5                        ",
char far tbl_input_4_4_7[] = "4.6                        ",
char far tbl_input_4_4_8[] = "4.7                        ",


/* INPUT CARD: 32IN5  **/
/***********************/
char far tbl_input_5_1_1[] = "1.0                        ",
char far tbl_input_5_1_2[] = "1.1                        ",
char far tbl_input_5_1_3[] = "1.2                        ",
char far tbl_input_5_1_4[] = "1.3                        ",
char far tbl_input_5_1_5[] = "1.4                        ",
char far tbl_input_5_1_6[] = "1.5                        ",
char far tbl_input_5_1_7[] = "1.6                        ",
char far tbl_input_5_1_8[] = "1.7                        ",

char far tbl_input_5_2_1[] = "2.0                        ",
char far tbl_input_5_2_2[] = "2.1                        ",
char far tbl_input_5_2_3[] = "2.2                        ",
char far tbl_input_5_2_4[] = "2.3                        ",
char far tbl_input_5_2_5[] = "2.4                        ",
char far tbl_input_5_2_6[] = "2.5                        ",
char far tbl_input_5_2_7[] = "2.6                        ",
char far tbl_input_5_2_8[] = "2.7                        ",

char far tbl_input_5_3_1[] = "3.0                        ",
char far tbl_input_5_3_2[] = "3.1                        ",
char far tbl_input_5_3_3[] = "3.2                        ",
char far tbl_input_5_3_4[] = "3.3                        ",
char far tbl_input_5_3_5[] = "3.4                        ",
char far tbl_input_5_3_6[] = "3.5                        ",
char far tbl_input_5_3_7[] = "3.6                        ",
char far tbl_input_5_3_8[] = "3.7                        ",

char far tbl_input_5_4_1[] = "4.0                        ",
char far tbl_input_5_4_2[] = "4.1                        ",
char far tbl_input_5_4_3[] = "4.2                        ",
char far tbl_input_5_4_4[] = "4.3                        ",
char far tbl_input_5_4_5[] = "4.4                        ",
char far tbl_input_5_4_6[] = "4.5                        ",
char far tbl_input_5_4_7[] = "4.6                        ",
char far tbl_input_5_4_8[] = "4.7                        ",


/* INPUT CARD: 32IN6  **/
/***********************/
char far tbl_input_6_1_1[] = "1.0                        ",
char far tbl_input_6_1_2[] = "1.1                        ",
char far tbl_input_6_1_3[] = "1.2                        ",
char far tbl_input_6_1_4[] = "1.3                        ",
char far tbl_input_6_1_5[] = "1.4                        ",
char far tbl_input_6_1_6[] = "1.5                        ",
char far tbl_input_6_1_7[] = "1.6                        ",
char far tbl_input_6_1_8[] = "1.7                        ",

char far tbl_input_6_2_1[] = "2.0                        ",
char far tbl_input_6_2_2[] = "2.1                        ",
char far tbl_input_6_2_3[] = "2.2                        ",
char far tbl_input_6_2_4[] = "2.3                        ",
char far tbl_input_6_2_5[] = "2.4                        ",
char far tbl_input_6_2_6[] = "2.5                        ",
char far tbl_input_6_2_7[] = "2.6                        ",
char far tbl_input_6_2_8[] = "2.7                        ",

char far tbl_input_6_3_1[] = "3.0                        ",
char far tbl_input_6_3_2[] = "3.1                        ",
char far tbl_input_6_3_3[] = "3.2                        ",
char far tbl_input_6_3_4[] = "3.3                        ",
char far tbl_input_6_3_5[] = "3.4                        ",
char far tbl_input_6_3_6[] = "3.5                        ",
char far tbl_input_6_3_7[] = "3.6                        ",
char far tbl_input_6_3_8[] = "3.7                        ",

char far tbl_input_6_4_1[] = "4.0                        ",
char far tbl_input_6_4_2[] = "4.1                        ",
char far tbl_input_6_4_3[] = "4.2                        ",
char far tbl_input_6_4_4[] = "4.3                        ",
char far tbl_input_6_4_5[] = "4.4                        ",
char far tbl_input_6_4_6[] = "4.5                        ",
char far tbl_input_6_4_7[] = "4.6                        ",
char far tbl_input_6_4_8[] = "4.7                        ",


/* INPUT CARD: 32IN7  **/
/***********************/
char far tbl_input_7_1_1[] = "1.0                        ",
char far tbl_input_7_1_2[] = "1.1                        ",
char far tbl_input_7_1_3[] = "1.2                        ",
char far tbl_input_7_1_4[] = "1.3                        ",
char far tbl_input_7_1_5[] = "1.4                        ",
char far tbl_input_7_1_6[] = "1.5                        ",
char far tbl_input_7_1_7[] = "1.6                        ",
char far tbl_input_7_1_8[] = "1.7                        ",

char far tbl_input_7_2_1[] = "2.0                        ",
char far tbl_input_7_2_2[] = "2.1                        ",
char far tbl_input_7_2_3[] = "2.2                        ",
char far tbl_input_7_2_4[] = "2.3                        ",
char far tbl_input_7_2_5[] = "2.4                        ",
char far tbl_input_7_2_6[] = "2.5                        ",
char far tbl_input_7_2_7[] = "2.6                        ",
char far tbl_input_7_2_8[] = "2.7                        ",

char far tbl_input_7_3_1[] = "3.0                        ",
char far tbl_input_7_3_2[] = "3.1                        ",
char far tbl_input_7_3_3[] = "3.2                        ",
char far tbl_input_7_3_4[] = "3.3                        ",
char far tbl_input_7_3_5[] = "3.4                        ",
char far tbl_input_7_3_6[] = "3.5                        ",
char far tbl_input_7_3_7[] = "3.6                        ",
char far tbl_input_7_3_8[] = "3.7                        ",

char far tbl_input_7_4_1[] = "4.0                        ",
char far tbl_input_7_4_2[] = "4.1                        ",
char far tbl_input_7_4_3[] = "4.2                        ",
char far tbl_input_7_4_4[] = "4.3                        ",
char far tbl_input_7_4_5[] = "4.4                        ",
char far tbl_input_7_4_6[] = "4.5                        ",
char far tbl_input_7_4_7[] = "4.5                        ",
char far tbl_input_7_4_8[] = "4.7                        ",


/* INPUT CARD: 32IN8  **/
/***********************/
char far tbl_input_8_1_1[] = "1.0                        ",
char far tbl_input_8_1_2[] = "1.1                        ",
char far tbl_input_8_1_3[] = "1.2                        ",
char far tbl_input_8_1_4[] = "1.3                        ",
char far tbl_input_8_1_5[] = "1.4                        ",
char far tbl_input_8_1_6[] = "1.5                        ",
char far tbl_input_8_1_7[] = "1.6                        ",
char far tbl_input_8_1_8[] = "1.7                        ",

char far tbl_input_8_2_1[] = "2.0                        ",
char far tbl_input_8_2_2[] = "2.1                        ",
char far tbl_input_8_2_3[] = "2.2                        ",
char far tbl_input_8_2_4[] = "2.3                        ",
char far tbl_input_8_2_5[] = "2.4                        ",
char far tbl_input_8_2_6[] = "2.5                        ",
char far tbl_input_8_2_7[] = "2.6                        ",
char far tbl_input_8_2_8[] = "2.7                        ",

char far tbl_input_8_3_1[] = "3.0                        ",
char far tbl_input_8_3_2[] = "3.1                        ",
char far tbl_input_8_3_3[] = "3.2                        ",
char far tbl_input_8_3_4[] = "3.3                        ",
char far tbl_input_8_3_5[] = "3.4                        ",
char far tbl_input_8_3_6[] = "3.5                        ",
char far tbl_input_8_3_7[] = "3.6                        ",
char far tbl_input_8_3_8[] = "3.7                        ",

char far tbl_input_8_4_1[] = "4.0                        ",
char far tbl_input_8_4_2[] = "4.1                        ",
char far tbl_input_8_4_3[] = "4.2                        ",
char far tbl_input_8_4_4[] = "4.3                        ",
char far tbl_input_8_4_5[] = "4.4                        ",
char far tbl_input_8_4_6[] = "4.5                        ",
char far tbl_input_8_4_7[] = "4.5                        ",
char far tbl_input_8_4_8[] = "4.7                        ",


/* INPUT CARD: 32IN9  **/
/***********************/
char far tbl_input_9_1_1[] = "1.0                        ",
char far tbl_input_9_1_2[] = "1.1                        ",
char far tbl_input_9_1_3[] = "1.2                        ",
char far tbl_input_9_1_4[] = "1.3                        ",
char far tbl_input_9_1_5[] = "1.4                        ",
char far tbl_input_9_1_6[] = "1.5                        ",
char far tbl_input_9_1_7[] = "1.6                        ",
char far tbl_input_9_1_8[] = "1.7                        ",

char far tbl_input_9_2_1[] = "2.0                        ",
char far tbl_input_9_2_2[] = "2.1                        ",
char far tbl_input_9_2_3[] = "2.2                        ",
char far tbl_input_9_2_4[] = "2.3                        ",
char far tbl_input_9_2_5[] = "2.4                        ",
char far tbl_input_9_2_6[] = "2.5                        ",
char far tbl_input_9_2_7[] = "2.6                        ",
char far tbl_input_9_2_8[] = "2.7                        ",

char far tbl_input_9_3_1[] = "3.0                        ",
char far tbl_input_9_3_2[] = "3.1                        ",
char far tbl_input_9_3_3[] = "3.2                        ",
char far tbl_input_9_3_4[] = "3.3                        ",
char far tbl_input_9_3_5[] = "3.4                        ",
char far tbl_input_9_3_6[] = "3.5                        ",
char far tbl_input_9_3_7[] = "3.6                        ",
char far tbl_input_9_3_8[] = "3.7                        ",

char far tbl_input_9_4_1[] = "4.0                        ",
char far tbl_input_9_4_2[] = "4.1                        ",
char far tbl_input_9_4_3[] = "4.2                        ",
char far tbl_input_9_4_4[] = "4.3                        ",
char far tbl_input_9_4_5[] = "4.4                        ",
char far tbl_input_9_4_6[] = "4.5                        ",
char far tbl_input_9_4_7[] = "4.5                        ",
char far tbl_input_9_4_8[] = "4.7                        ",


/* CAN_STATION_1 32IN P01->P04  **/
/*********************************/
char far tbl_input_S1_01_1[] = "1.1.1 In From Line: EFG    ",
char far tbl_input_S1_01_2[] = "1.1.2 In From Line: MAG    ",
char far tbl_input_S1_01_3[] = "1#1#3 BP Machine FAST STOP ",
char far tbl_input_S1_01_4[] = "1#1#4 In SlowSpeedDoors OK ",
char far tbl_input_S1_01_5[] = "1.1.5 BT Machine Work-Mode ",
char far tbl_input_S1_01_6[] = "1#1#6 In Emergency-Cable   ",
char far tbl_input_S1_01_7[] = "1.1.7                      ",
char far tbl_input_S1_01_8[] = "1.1.8                      ",
                                                           
char far tbl_input_S1_02_1[] = "1.2.1 Emerg.Mod. #1 FAULT  ",
char far tbl_input_S1_02_2[] = "1.2.2 Emerg.Mod. #2 FAULT  ",
char far tbl_input_S1_02_3[] = "1.2.3 Emerg.Mod. DELAYED OK",
char far tbl_input_S1_02_4[] = "1.2.4 In ZeroSpeedDoors  OK",
char far tbl_input_S1_02_5[] = "1.2.5 BP Emerg.Buttons FLT ",
char far tbl_input_S1_02_6[] = "1.2.6 Braking Resistance OK",
char far tbl_input_S1_02_7[] = "1.2.7                      ",
char far tbl_input_S1_02_8[] = "1.2.8                      ",
                                                           
char far tbl_input_S1_03_1[] = "1.3.1 DisJ BrakeRotSR FAULT",
char far tbl_input_S1_03_2[] = "1.3.2 DisJ BrakeRotCP FAULT",
char far tbl_input_S1_03_3[] = "1.3.3 DisJ MotRotCP   FAULT",
char far tbl_input_S1_03_4[] = "1.3.4 DisJ MotInsert. FAULT",
char far tbl_input_S1_03_5[] = "1#3#5 TherProt. MotAsp. FLT",
char far tbl_input_S1_03_6[] = "1#3#6 TherProt. MotGCL OK  ",
char far tbl_input_S1_03_7[] = "1.3.7                      ",
char far tbl_input_S1_03_8[] = "1.3.8                      ",
                                                           
char far tbl_input_S1_04_1[] = "1.4.1 BP Run Mot.Insertion ",
char far tbl_input_S1_04_2[] = "1.4.2 BP Run Prod.Traction ",
char far tbl_input_S1_04_3[] = "1.4.3 BT Rotation-SR FRONT ",
char far tbl_input_S1_04_4[] = "1.4.4 BT Rotation-SR BACK  ",
char far tbl_input_S1_04_5[] = "1.4.5 BT Rotation-CP FRONT ",
char far tbl_input_S1_04_6[] = "1.4.6 BT Rotation-CP BACK  ",
char far tbl_input_S1_04_7[] = "1.4.7                      ",
char far tbl_input_S1_04_8[] = "1.4.8                      ",


/* CAN_STATION_1 32IN P05->P08  **/
/*********************************/
char far tbl_input_S1_05_1[] = "1#5#1 In Emergency-Line OK ",
char far tbl_input_S1_05_2[] = "1#5#2 In Emergency-Table OK",
char far tbl_input_S1_05_3[] = "1#5#3 In Emergency-Crane OK",
char far tbl_input_S1_05_4[] = "1#5#4 DP TranslTable WORK  ",
char far tbl_input_S1_05_5[] = "1#5#5 DP TranslTable REST  ",
char far tbl_input_S1_05_6[] = "1#5#6 In PHCELL TranslTable",
char far tbl_input_S1_05_7[] = "1.5.7                      ",
char far tbl_input_S1_05_8[] = "1.5.8                      ",
                                                             
char far tbl_input_S1_06_1[] = "1#6#1 In SafetyBarrier OK  ",
char far tbl_input_S1_06_2[] = "1#6#2 BP SafetyBarrierReset",
char far tbl_input_S1_06_3[] = "1#6#3 BT CraneRemoteControl",
char far tbl_input_S1_06_4[] = "1.6.4 ...                  ",
char far tbl_input_S1_06_5[] = "1.6.5 ...                  ",
char far tbl_input_S1_06_6[] = "1.6.6 ...                  ",
char far tbl_input_S1_06_7[] = "1.6.7                      ",
char far tbl_input_S1_06_8[] = "1.6.8                      ",
                                                             
char far tbl_input_S1_07_1[] = "1.7.1                      ",
char far tbl_input_S1_07_2[] = "1.7.2                      ",
char far tbl_input_S1_07_3[] = "1.7.3                      ",
char far tbl_input_S1_07_4[] = "1.7.4                      ",
char far tbl_input_S1_07_5[] = "1.7.5                      ",
char far tbl_input_S1_07_6[] = "1.7.6                      ",
char far tbl_input_S1_07_7[] = "1.7.7                      ",
char far tbl_input_S1_07_8[] = "1.7.8                      ",
                                                             
char far tbl_input_S1_08_1[] = "1.8.1                      ",
char far tbl_input_S1_08_2[] = "1.8.2                      ",
char far tbl_input_S1_08_3[] = "1.8.3                      ",
char far tbl_input_S1_08_4[] = "1.8.4                      ",
char far tbl_input_S1_08_5[] = "1.8.5                      ",
char far tbl_input_S1_08_6[] = "1.8.6                      ",
char far tbl_input_S1_08_7[] = "1.8.7                      ",
char far tbl_input_S1_08_8[] = "1.8.8                      ",


/* CAN_STATION_2 32IN P01->P04  **/
/*********************************/
char far tbl_input_S2_01_1[] = "2.1.1 DP Transl.GCT  BACK  ",
char far tbl_input_S2_01_2[] = "2#1#2 DP Appl.RP2 WORK (up)",
char far tbl_input_S2_01_3[] = "2#1#3 DP Appl.RP2 REST (dw)",
char far tbl_input_S2_01_4[] = "2#1#4 DP Shaft 3-INCH on CP",
char far tbl_input_S2_01_5[] = "2.1.5 DP AirSource-GCT REST",
char far tbl_input_S2_01_6[] = "2.1.6 DP Air-Pressure OK   ",
char far tbl_input_S2_01_7[] = "2.1.7                      ",
char far tbl_input_S2_01_8[] = "2.1.8                      ",
                                                             
char far tbl_input_S2_02_1[] = "2.2.1 DP HookCS WORK(MotS) ",
char far tbl_input_S2_02_2[] = "2.2.2 DP HookCS REST(MotS) ",
char far tbl_input_S2_02_3[] = "2.2.3 DP KookCS WORK(OperS)",
char far tbl_input_S2_02_4[] = "2.2.4 DP KookCS REST(OperS)",
char far tbl_input_S2_02_5[] = "2#2#5 DP Shaft 6-INCH on CS",
char far tbl_input_S2_02_6[] = "2.2.6 ...                  ",
char far tbl_input_S2_02_7[] = "2.2.7                      ",
char far tbl_input_S2_02_8[] = "2.2.8                      ",
                                                             
char far tbl_input_S2_03_1[] = "2.3.1 ...                  ",
char far tbl_input_S2_03_2[] = "2.3.2 ...                  ",
char far tbl_input_S2_03_3[] = "2.3.3 DPNC Rotation-CP MAX ",
char far tbl_input_S2_03_4[] = "2.3.4 DPNC Rotation-CP MIN ",
char far tbl_input_S2_03_5[] = "2.3.5 DP HookCP WORK(MotS) ",
char far tbl_input_S2_03_6[] = "2.3.6 DP HookCP REST(MotS) ",
char far tbl_input_S2_03_7[] = "2.3.7                      ",
char far tbl_input_S2_03_8[] = "2.3.8                      ",
                                                             
char far tbl_input_S2_04_1[] = "2.4.1 DP HookCP WORK(OperS)",
char far tbl_input_S2_04_2[] = "2.4.2 DP HookCP REST(OperS)",
char far tbl_input_S2_04_3[] = "2.4.3 DP CP-Shaft-Presence ",
char far tbl_input_S2_04_4[] = "2.4.4 DP Transl.CP REST(dw)",
char far tbl_input_S2_04_5[] = "2.4.5 DP Transl.CP WORK(up)",
char far tbl_input_S2_04_6[] = "2.4.6 DP Transl.CP CUT-POS.",
char far tbl_input_S2_04_7[] = "2.4.7                      ",
char far tbl_input_S2_04_8[] = "2.4.8                      ",
                                                             
                                                             
/* CAN_STATION_2 32IN P05->P08  **/                          
/*********************************/                          
char far tbl_input_S2_05_1[] = "2#5#1 DP ShaftGCL Press. OK",
char far tbl_input_S2_05_2[] = "2#5#2 DP AxisDrive WORK(in)",
char far tbl_input_S2_05_3[] = "2#5#3 DP AxisDrive REST(ou)",
char far tbl_input_S2_05_4[] = "2.5.4 DPNC Rot.SR ON CAM   ",
char far tbl_input_S2_05_5[] = "2#5#5 DP Reel-Brake WORK   ",
char far tbl_input_S2_05_6[] = "2.5.6 DP Shaft UnloadingPos",
char far tbl_input_S2_05_7[] = "2.5.7                      ",
char far tbl_input_S2_05_8[] = "2.5.8                      ",
                                                             
char far tbl_input_S2_05_1[] = "2#6#1 DP Arms-MABF WORK(dw)",
char far tbl_input_S2_06_2[] = "2#6#2 DP Arms-MABF REST(up)",
char far tbl_input_S2_06_3[] = "2.6.3 DP Arms/Cam Presence ",
char far tbl_input_S2_06_4[] = "2.6.4 DP Cam-MABF WORK (bk)",
char far tbl_input_S2_06_5[] = "2.6.5 DP Cam-MABF REST (fr)",
char far tbl_input_S2_06_6[] = "2.6.6 DP Cam Presen.(OperS)",
char far tbl_input_S2_06_7[] = "2.6.7                      ",
char far tbl_input_S2_06_8[] = "2.6.8                      ",
                                                             
char far tbl_input_S2_07_1[] = "2.7.1                      ",
char far tbl_input_S2_07_2[] = "2.7.2                      ",
char far tbl_input_S2_07_3[] = "2.7.3                      ",
char far tbl_input_S2_07_4[] = "2.7.4                      ",
char far tbl_input_S2_07_5[] = "2.7.5                      ",
char far tbl_input_S2_07_6[] = "2.7.6                      ",
char far tbl_input_S2_07_7[] = "2.7.7                      ",
char far tbl_input_S2_07_8[] = "2.7.8                      ",
                                                             
char far tbl_input_S2_08_1[] = "2.8.1                      ",
char far tbl_input_S2_08_2[] = "2.8.2                      ",
char far tbl_input_S2_08_3[] = "2.8.3                      ",
char far tbl_input_S2_08_4[] = "2.8.4                      ",
char far tbl_input_S2_08_5[] = "2.8.5                      ",
char far tbl_input_S2_08_6[] = "2.8.6                      ",
char far tbl_input_S2_08_7[] = "2.8.7                      ",
char far tbl_input_S2_08_8[] = "2.8.8                      ",


/* CAN_STATION_3 32IN P01->P04  **/
/*********************************/
char far tbl_input_S3_01_1[] = "3#1#1 In Crane Enabled     ",
char far tbl_input_S3_01_2[] = "3#1#2 In Crane MAX Load OK ",
char far tbl_input_S3_01_3[] = "3#1#3 In Crane MIN Load OK ",
char far tbl_input_S3_01_4[] = "3#1#4 In Crane ZERO Load OK",
char far tbl_input_S3_01_5[] = "3#1#5 In CraneDrives  FAULT",
char far tbl_input_S3_01_6[] = "3#1#6 In CraneThermal FAULT",
char far tbl_input_S3_01_7[] = "3.1.7                      ",
char far tbl_input_S3_01_8[] = "3.1.8                      ",
                                                           
char far tbl_input_S3_02_1[] = "3#2#1 BP TranslCrn Forward ",
char far tbl_input_S3_02_2[] = "3#2#2 BP TranslCrn Backward",
char far tbl_input_S3_02_3[] = "3#2#3 BP TranslCrnFastSpeed",
char far tbl_input_S3_02_4[] = "3#2#4 BP VertCrn Up        ",
char far tbl_input_S3_02_5[] = "3#2#5 BP VertCrn Down      ",
char far tbl_input_S3_02_6[] = "3#2#6 BP VertCrn FastSpeed ",
char far tbl_input_S3_02_7[] = "3.2.7                      ",
char far tbl_input_S3_02_8[] = "3.2.8                      ",
                                                           
char far tbl_input_S3_03_1[] = "3#3#1 BP RotArmCrane toWork",
char far tbl_input_S3_03_2[] = "3#3#2 BP RotArmCrane toRest",
char far tbl_input_S3_03_3[] = "3#3#3 BP PliersGroup toWork",
char far tbl_input_S3_03_4[] = "3#3#4 BP PliersGroup toRest",
char far tbl_input_S3_03_5[] = "3#3#5 BP Pliers toWork     ",
char far tbl_input_S3_03_6[] = "3#3#6 BP Pliers toRest     ",
char far tbl_input_S3_03_7[] = "3.3.7                      ",
char far tbl_input_S3_03_8[] = "3.3.8                      ",
                                                           
char far tbl_input_S3_04_1[] = "3#4#1 BP Vice toWork       ",
char far tbl_input_S3_04_2[] = "3#4#2 BP Vice toRest       ",
char far tbl_input_S3_04_3[] = "3#4#3 BP Pin toWork        ",
char far tbl_input_S3_04_4[] = "3#4#4 BP Pin toRest        ",
char far tbl_input_S3_04_5[] = "3#4#5 BP AirPin toWork     ",
char far tbl_input_S3_04_6[] = "3#4#6 BP AirPin toRest     ",
char far tbl_input_S3_04_7[] = "3.4.7                      ",
char far tbl_input_S3_04_8[] = "3.4.8                      ",


/* CAN_STATION_3 32IN P05->P08  **/
/*********************************/
char far tbl_input_S3_05_1[] = "3#5#1 BP Crane FaultReset  ",
char far tbl_input_S3_05_2[] = "3#5#2 DP TranslCrn Forward ",
char far tbl_input_S3_05_3[] = "3#5#3 DP TranslCrn Backward",
char far tbl_input_S3_05_4[] = "3#5#4 DP TranslCrnSlwDwForw",
char far tbl_input_S3_05_5[] = "3#5#5 DP TranslCrnSlwDwBack",
char far tbl_input_S3_05_6[] = "3#5#6 DP TranslCrnSlwDwLoad",
char far tbl_input_S3_05_7[] = "3.5.7                      ",
char far tbl_input_S3_05_8[] = "3.5.8                      ",
                                                           
char far tbl_input_S3_05_1[] = "3#6#1 DP TranslCrn Load_1  ",
char far tbl_input_S3_06_2[] = "3#6#2 DP TranslCrn Load_2  ",
char far tbl_input_S3_06_3[] = "3#6#3 DP VertCrane Upper   ",
char far tbl_input_S3_06_4[] = "3#6#4 DP VertCrane Lower   ",
char far tbl_input_S3_06_5[] = "3#6#5 DP VertCrane Loading ",
char far tbl_input_S3_06_6[] = "3#6#6 DP VrtCrn ShaftUnLoad",
char far tbl_input_S3_06_7[] = "3.6.7                      ",
char far tbl_input_S3_06_8[] = "3.6.8                      ",
                                                           
char far tbl_input_S3_07_1[] = "3#7#1 DP RotArmCrane Work  ",
char far tbl_input_S3_07_2[] = "3#7#2 DP RotArmCrane Rest  ",
char far tbl_input_S3_07_3[] = "3#7#3 DP Shaft-OK Mot.Side ",
char far tbl_input_S3_07_4[] = "3#7#4 DP Shaft-OK Ope.Side ",
char far tbl_input_S3_07_5[] = "3#7#5 DP PliersGroup Work  ",
char far tbl_input_S3_07_6[] = "3#7#6 DP PliersGroup Rest  ",
char far tbl_input_S3_07_7[] = "3.7.7                      ",
char far tbl_input_S3_07_8[] = "3.7.8                      ",
                                                           
char far tbl_input_S3_08_1[] = "3#8#1 DP Vice Work         ",
char far tbl_input_S3_08_2[] = "3#8#2 DP Vice Rest         ",
char far tbl_input_S3_08_3[] = "3#8#3 DP Pin Work          ",
char far tbl_input_S3_08_4[] = "3#8#4 DP Pin Rest          ",
char far tbl_input_S3_08_5[] = "3#8#5 Pin AirPressure FAULT",
char far tbl_input_S3_08_6[] = "3#8#6 In Crane Buzzer ON   ",
char far tbl_input_S3_08_7[] = "3.8.7                      ",
char far tbl_input_S3_08_8[] = "3.8.8                      ",


/* CAN_STATION_4 32IN P01->P04  **/
/*********************************/
char far tbl_input_S4_01_1[] = "4.1.1                      ",
char far tbl_input_S4_01_2[] = "4.1.2                      ",
char far tbl_input_S4_01_3[] = "4.1.3                      ",
char far tbl_input_S4_01_4[] = "4.1.4                      ",
char far tbl_input_S4_01_5[] = "4.1.5                      ",
char far tbl_input_S4_01_6[] = "4.1.6                      ",
char far tbl_input_S4_01_7[] = "4.1.7                      ",
char far tbl_input_S4_01_8[] = "4.1.8                      ",
                                                           
char far tbl_input_S4_02_1[] = "4.2.1                      ",
char far tbl_input_S4_02_2[] = "4.2.2                      ",
char far tbl_input_S4_02_3[] = "4.2.3                      ",
char far tbl_input_S4_02_4[] = "4.2.4                      ",
char far tbl_input_S4_02_5[] = "4.2.5                      ",
char far tbl_input_S4_02_6[] = "4.2.6                      ",
char far tbl_input_S4_02_7[] = "4.2.7                      ",
char far tbl_input_S4_02_8[] = "4.2.8                      ",
                                                           
char far tbl_input_S4_03_1[] = "4.3.1                      ",
char far tbl_input_S4_03_2[] = "4.3.2                      ",
char far tbl_input_S4_03_3[] = "4.3.3                      ",
char far tbl_input_S4_03_4[] = "4.3.4                      ",
char far tbl_input_S4_03_5[] = "4.3.5                      ",
char far tbl_input_S4_03_6[] = "4.3.6                      ",
char far tbl_input_S4_03_7[] = "4.3.7                      ",
char far tbl_input_S4_03_8[] = "4.3.8                      ",
                                                           
char far tbl_input_S4_04_1[] = "4.4.1                      ",
char far tbl_input_S4_04_2[] = "4.4.2                      ",
char far tbl_input_S4_04_3[] = "4.4.3                      ",
char far tbl_input_S4_04_4[] = "4.4.4                      ",
char far tbl_input_S4_04_5[] = "4.4.5                      ",
char far tbl_input_S4_04_6[] = "4.4.6                      ",
char far tbl_input_S4_04_7[] = "4.4.7                      ",
char far tbl_input_S4_04_8[] = "4.4.8                      ",
                                                           
                                                           
/* CAN_STATION_4 32IN P05->P08  **                         
/*********************************                         
char far tbl_input_S4_05_1[] = "4.5.1                      ",
char far tbl_input_S4_05_2[] = "4.5.2                      ",
char far tbl_input_S4_05_3[] = "4.5.3                      ",
char far tbl_input_S4_05_4[] = "4.5.4                      ",
char far tbl_input_S4_05_5[] = "4.5.5                      ",
char far tbl_input_S4_05_6[] = "4.5.6                      ",
char far tbl_input_S4_05_7[] = "4.5.7                      ",
char far tbl_input_S4_05_8[] = "4.5.8                      ",
                                                           
char far tbl_input_S4_05_1[] = "4.6.1                      ",
char far tbl_input_S4_06_2[] = "4.6.2                      ",
char far tbl_input_S4_06_3[] = "4.6.3                      ",
char far tbl_input_S4_06_4[] = "4.6.4                      ",
char far tbl_input_S4_06_5[] = "4.6.5                      ",
char far tbl_input_S4_06_6[] = "4.6.6                      ",
char far tbl_input_S4_06_7[] = "4.6.7                      ",
char far tbl_input_S4_06_8[] = "4.6.8                      ",
                                                           
char far tbl_input_S4_07_1[] = "4.7.1                      ",
char far tbl_input_S4_07_2[] = "4.7.2                      ",
char far tbl_input_S4_07_3[] = "4.7.3                      ",
char far tbl_input_S4_07_4[] = "4.7.4                      ",
char far tbl_input_S4_07_5[] = "4.7.5                      ",
char far tbl_input_S4_07_6[] = "4.7.6                      ",
char far tbl_input_S4_07_7[] = "4.7.7                      ",
char far tbl_input_S4_07_8[] = "4.7.8                      ",
                                                           
char far tbl_input_S4_08_1[] = "4.8.1                      ",
char far tbl_input_S4_08_2[] = "4.8.2                      ",
char far tbl_input_S4_08_3[] = "4.8.3                      ",
char far tbl_input_S4_08_4[] = "4.8.4                      ",
char far tbl_input_S4_08_5[] = "4.8.5                      ",
char far tbl_input_S4_08_6[] = "4.8.6                      ",
char far tbl_input_S4_08_7[] = "4.8.7                      ",
char far tbl_input_S4_08_8[] = "4.8.8                      ",
                                                           
                                                           
/* CAN_STATION_5 32IN P01->P04  **                         
/*********************************                         
char far tbl_input_S5_01_1[] = "5.1.1                      ",
char far tbl_input_S5_01_2[] = "5.1.2                      ",
char far tbl_input_S5_01_3[] = "5.1.3                      ",
char far tbl_input_S5_01_4[] = "5.1.4                      ",
char far tbl_input_S5_01_5[] = "5.1.5                      ",
char far tbl_input_S5_01_6[] = "5.1.6                      ",
char far tbl_input_S5_01_7[] = "5.1.7                      ",
char far tbl_input_S5_01_8[] = "5.1.8                      ",
                                                           
char far tbl_input_S5_02_1[] = "5.2.1                      ",
char far tbl_input_S5_02_2[] = "5.2.2                      ",
char far tbl_input_S5_02_3[] = "5.2.3                      ",
char far tbl_input_S5_02_4[] = "5.2.4                      ",
char far tbl_input_S5_02_5[] = "5.2.5                      ",
char far tbl_input_S5_02_6[] = "5.2.6                      ",
char far tbl_input_S5_02_7[] = "5.2.7                      ",
char far tbl_input_S5_02_8[] = "5.2.8                      ",
                                                           
char far tbl_input_S5_03_1[] = "5.3.1                      ",
char far tbl_input_S5_03_2[] = "5.3.2                      ",
char far tbl_input_S5_03_3[] = "5.3.3                      ",
char far tbl_input_S5_03_4[] = "5.3.4                      ",
char far tbl_input_S5_03_5[] = "5.3.5                      ",
char far tbl_input_S5_03_6[] = "5.3.6                      ",
char far tbl_input_S5_03_7[] = "5.3.7                      ",
char far tbl_input_S5_03_8[] = "5.3.8                      ",
                                                           
char far tbl_input_S5_04_1[] = "5.4.1                      ",
char far tbl_input_S5_04_2[] = "5.4.2                      ",
char far tbl_input_S5_04_3[] = "5.4.3                      ",
char far tbl_input_S5_04_4[] = "5.4.4                      ",
char far tbl_input_S5_04_5[] = "5.4.5                      ",
char far tbl_input_S5_04_6[] = "5.4.6                      ",
char far tbl_input_S5_04_7[] = "5.4.7                      ",
char far tbl_input_S5_04_8[] = "5.4.8                      ",
                                                           
                                                           
/* CAN_STATION_5 32IN P05->P08  **                         
/*********************************                         
char far tbl_input_S5_05_1[] = "5.5.1                      ",
char far tbl_input_S5_05_2[] = "5.5.2                      ",
char far tbl_input_S5_05_3[] = "5.5.3                      ",
char far tbl_input_S5_05_4[] = "5.5.4                      ",
char far tbl_input_S5_05_5[] = "5.5.5                      ",
char far tbl_input_S5_05_6[] = "5.5.6                      ",
char far tbl_input_S5_05_7[] = "5.5.7                      ",
char far tbl_input_S5_05_8[] = "5.5.8                      ",
                                                           
char far tbl_input_S5_05_1[] = "5.6.1                      ",
char far tbl_input_S5_06_2[] = "5.6.2                      ",
char far tbl_input_S5_06_3[] = "5.6.3                      ",
char far tbl_input_S5_06_4[] = "5.6.4                      ",
char far tbl_input_S5_06_5[] = "5.6.5                      ",
char far tbl_input_S5_06_6[] = "5.6.6                      ",
char far tbl_input_S5_06_7[] = "5.6.7                      ",
char far tbl_input_S5_06_8[] = "5.6.8                      ",
                                                           
char far tbl_input_S5_07_1[] = "5.7.1                      ",
char far tbl_input_S5_07_2[] = "5.7.2                      ",
char far tbl_input_S5_07_3[] = "5.7.3                      ",
char far tbl_input_S5_07_4[] = "5.7.4                      ",
char far tbl_input_S5_07_5[] = "5.7.5                      ",
char far tbl_input_S5_07_6[] = "5.7.6                      ",
char far tbl_input_S5_07_7[] = "5.7.7                      ",
char far tbl_input_S5_07_8[] = "5.7.8                      ",
                                                           
char far tbl_input_S5_08_1[] = "5.8.1                      ",
char far tbl_input_S5_08_2[] = "5.8.2                      ",
char far tbl_input_S5_08_3[] = "5.8.3                      ",
char far tbl_input_S5_08_4[] = "5.8.4                      ",
char far tbl_input_S5_08_5[] = "5.8.5                      ",
char far tbl_input_S5_08_6[] = "5.8.6                      ",
char far tbl_input_S5_08_7[] = "5.8.7                      ",
char far tbl_input_S5_08_8[] = "5.8.8                      ",








/* Table of the outputs                                       */
/* char *tbl_output[] =                                       */
/*                             123456789012345678901234567    */
char far tbl_output00[]     = "                           ";

/* INPUT CARD: 32OUT1 **/
/***********************/
char far tbl_output_1_1_1[] = "1.0                        ",
char far tbl_output_1_1_2[] = "1.1                        ",
char far tbl_output_1_1_3[] = "1.2                        ",
char far tbl_output_1_1_4[] = "1.3                        ",
char far tbl_output_1_1_5[] = "1.4                        ",
char far tbl_output_1_1_6[] = "1.5                        ",
char far tbl_output_1_1_7[] = "1.6                        ",
char far tbl_output_1_1_8[] = "1.7                        ",

char far tbl_output_1_2_1[] = "2.0                        ",
char far tbl_output_1_2_2[] = "2.1                        ",
char far tbl_output_1_2_3[] = "2.2                        ",
char far tbl_output_1_2_4[] = "2.3                        ",
char far tbl_output_1_2_5[] = "2.4                        ",
char far tbl_output_1_2_6[] = "2.5                        ",
char far tbl_output_1_2_7[] = "2.6                        ",
char far tbl_output_1_2_8[] = "2.7                        ",

char far tbl_output_1_3_1[] = "3.0                        ",
char far tbl_output_1_3_2[] = "3.1                        ",
char far tbl_output_1_3_3[] = "3.2                        ",
char far tbl_output_1_3_4[] = "3.3                        ",
char far tbl_output_1_3_5[] = "3.4                        ",
char far tbl_output_1_3_6[] = "3.5                        ",
char far tbl_output_1_3_7[] = "3.6                        ",
char far tbl_output_1_3_8[] = "3.7                        ",

char far tbl_output_1_4_1[] = "4.0                        ",
char far tbl_output_1_4_2[] = "4.1                        ",
char far tbl_output_1_4_3[] = "4.2                        ",
char far tbl_output_1_4_4[] = "4.3                        ",
char far tbl_output_1_4_5[] = "4.4                        ",
char far tbl_output_1_4_6[] = "4.5                        ",
char far tbl_output_1_4_7[] = "4.6                        ",
char far tbl_output_1_4_8[] = "4.7                        ",


/* INPUT CARD: 32OUT2 **/
/***********************/
char far tbl_output_2_1_1[] = "1.0                        ",
char far tbl_output_2_1_2[] = "1.1                        ",
char far tbl_output_2_1_3[] = "1.2                        ",
char far tbl_output_2_1_4[] = "1.3                        ",
char far tbl_output_2_1_5[] = "1.4                        ",
char far tbl_output_2_1_6[] = "1.5                        ",
char far tbl_output_2_1_7[] = "1.6                        ",
char far tbl_output_2_1_8[] = "1.7                        ",

char far tbl_output_2_2_1[] = "2.0                        ",
char far tbl_output_2_2_2[] = "2.1                        ",
char far tbl_output_2_2_3[] = "2.2                        ",
char far tbl_output_2_2_4[] = "2.3                        ",
char far tbl_output_2_2_5[] = "2.4                        ",
char far tbl_output_2_2_6[] = "2.5                        ",
char far tbl_output_2_2_7[] = "2.6                        ",
char far tbl_output_2_2_8[] = "2.7                        ",

char far tbl_output_2_3_1[] = "3.0                        ",
char far tbl_output_2_3_2[] = "3.1                        ",
char far tbl_output_2_3_3[] = "3.2                        ",
char far tbl_output_2_3_4[] = "3.3                        ",
char far tbl_output_2_3_5[] = "3.4                        ",
char far tbl_output_2_3_6[] = "3.5                        ",
char far tbl_output_2_3_7[] = "3.6                        ",
char far tbl_output_2_3_8[] = "3.7                        ",

char far tbl_output_2_4_1[] = "4.0                        ",
char far tbl_output_2_4_2[] = "4.1                        ",
char far tbl_output_2_4_3[] = "4.2                        ",
char far tbl_output_2_4_4[] = "4.3                        ",
char far tbl_output_2_4_5[] = "4.4                        ",
char far tbl_output_2_4_6[] = "4.5                        ",
char far tbl_output_2_4_7[] = "4.6                        ",
char far tbl_output_2_4_8[] = "4.7                        ",


/* INPUT CARD: 32OUT3 **/
/***********************/
char far tbl_output_3_1_1[] = "1.0                        ",
char far tbl_output_3_1_2[] = "1.1                        ",
char far tbl_output_3_1_3[] = "1.2                        ",
char far tbl_output_3_1_4[] = "1.3                        ",
char far tbl_output_3_1_5[] = "1.4                        ",
char far tbl_output_3_1_6[] = "1.5                        ",
char far tbl_output_3_1_7[] = "1.6                        ",
char far tbl_output_3_1_8[] = "1.7                        ",

char far tbl_output_3_2_1[] = "2.0                        ",
char far tbl_output_3_2_2[] = "2.1                        ",
char far tbl_output_3_2_3[] = "2.2                        ",
char far tbl_output_3_2_4[] = "2.3                        ",
char far tbl_output_3_2_5[] = "2.4                        ",
char far tbl_output_3_2_6[] = "2.5                        ",
char far tbl_output_3_2_7[] = "2.6                        ",
char far tbl_output_3_2_8[] = "2.7                        ",

char far tbl_output_3_3_1[] = "3.0                        ",
char far tbl_output_3_3_2[] = "3.1                        ",
char far tbl_output_3_3_3[] = "3.2                        ",
char far tbl_output_3_3_4[] = "3.3                        ",
char far tbl_output_3_3_5[] = "3.4                        ",
char far tbl_output_3_3_6[] = "3.5                        ",
char far tbl_output_3_3_7[] = "3.6                        ",
char far tbl_output_3_3_8[] = "3.7                        ",

char far tbl_output_3_4_1[] = "4.0                        ",
char far tbl_output_3_4_2[] = "4.1                        ",
char far tbl_output_3_4_3[] = "4.2                        ",
char far tbl_output_3_4_4[] = "4.3                        ",
char far tbl_output_3_4_5[] = "4.4                        ",
char far tbl_output_3_4_6[] = "4.5                        ",
char far tbl_output_3_4_7[] = "4.6                        ",
char far tbl_output_3_4_8[] = "4.7                        ",



/* INPUT CARD: 32OUT4 **/
/***********************/
char far tbl_output_4_1_1[] = "1.0                        ",
char far tbl_output_4_1_2[] = "1.1                        ",
char far tbl_output_4_1_3[] = "1.2                        ",
char far tbl_output_4_1_4[] = "1.3                        ",
char far tbl_output_4_1_5[] = "1.4                        ",
char far tbl_output_4_1_6[] = "1.5                        ",
char far tbl_output_4_1_7[] = "1.6                        ",
char far tbl_output_4_1_8[] = "1.7                        ",

char far tbl_output_4_2_1[] = "2.0                        ",
char far tbl_output_4_2_2[] = "2.1                        ",
char far tbl_output_4_2_3[] = "2.2                        ",
char far tbl_output_4_2_4[] = "2.3                        ",
char far tbl_output_4_2_5[] = "2.4                        ",
char far tbl_output_4_2_6[] = "2.5                        ",
char far tbl_output_4_2_7[] = "2.6                        ",
char far tbl_output_4_2_8[] = "2.7                        ",

char far tbl_output_4_3_1[] = "3.0                        ",
char far tbl_output_4_3_2[] = "3.1                        ",
char far tbl_output_4_3_3[] = "3.2                        ",
char far tbl_output_4_3_4[] = "3.3                        ",
char far tbl_output_4_3_5[] = "3.4                        ",
char far tbl_output_4_3_6[] = "3.5                        ",
char far tbl_output_4_3_7[] = "3.6                        ",
char far tbl_output_4_3_8[] = "3.7                        ",

char far tbl_output_4_4_1[] = "4.0                        ",
char far tbl_output_4_4_2[] = "4.1                        ",
char far tbl_output_4_4_3[] = "4.2                        ",
char far tbl_output_4_4_4[] = "4.3                        ",
char far tbl_output_4_4_5[] = "4.4                        ",
char far tbl_output_4_4_6[] = "4.5                        ",
char far tbl_output_4_4_7[] = "4.6                        ",
char far tbl_output_4_4_8[] = "4.7                        ",



/* INPUT CARD: 32OUT5 **/
/***********************/
char far tbl_output_5_1_1[] = "1.0                        ",
char far tbl_output_5_1_2[] = "1.1                        ",
char far tbl_output_5_1_3[] = "1.2                        ",
char far tbl_output_5_1_4[] = "1.3                        ",
char far tbl_output_5_1_5[] = "1.4                        ",
char far tbl_output_5_1_6[] = "1.5                        ",
char far tbl_output_5_1_7[] = "1.6                        ",
char far tbl_output_5_1_8[] = "1.7                        ",

char far tbl_output_5_2_1[] = "2.0                        ",
char far tbl_output_5_2_2[] = "2.1                        ",
char far tbl_output_5_2_3[] = "2.2                        ",
char far tbl_output_5_2_4[] = "2.3                        ",
char far tbl_output_5_2_5[] = "2.4                        ",
char far tbl_output_5_2_6[] = "2.5                        ",
char far tbl_output_5_2_7[] = "2.6                        ",
char far tbl_output_5_2_8[] = "2.7                        ",

char far tbl_output_5_3_1[] = "3.0                        ",
char far tbl_output_5_3_2[] = "3.1                        ",
char far tbl_output_5_3_3[] = "3.2                        ",
char far tbl_output_5_3_4[] = "3.3                        ",
char far tbl_output_5_3_5[] = "3.4                        ",
char far tbl_output_5_3_6[] = "3.5                        ",
char far tbl_output_5_3_7[] = "3.6                        ",
char far tbl_output_5_3_8[] = "3.7                        ",

char far tbl_output_5_4_1[] = "4.0                        ",
char far tbl_output_5_4_2[] = "4.1                        ",
char far tbl_output_5_4_3[] = "4.2                        ",
char far tbl_output_5_4_4[] = "4.3                        ",
char far tbl_output_5_4_5[] = "4.4                        ",
char far tbl_output_5_4_6[] = "4.5                        ",
char far tbl_output_5_4_7[] = "4.5                        ",
char far tbl_output_5_4_8[] = "4.7                        ",


/* INPUT CARD: 32OUT6 **/
/***********************/
char far tbl_output_6_1_1[] = "1.0                        ",
char far tbl_output_6_1_2[] = "1.1                        ",
char far tbl_output_6_1_3[] = "1.2                        ",
char far tbl_output_6_1_4[] = "1.3                        ",
char far tbl_output_6_1_5[] = "1.4                        ",
char far tbl_output_6_1_6[] = "1.5                        ",
char far tbl_output_6_1_7[] = "1.6                        ",
char far tbl_output_6_1_8[] = "1.7                        ",

char far tbl_output_6_2_1[] = "2.0                        ",
char far tbl_output_6_2_2[] = "2.1                        ",
char far tbl_output_6_2_3[] = "2.2                        ",
char far tbl_output_6_2_4[] = "2.3                        ",
char far tbl_output_6_2_5[] = "2.4                        ",
char far tbl_output_6_2_6[] = "2.5                        ",
char far tbl_output_6_2_7[] = "2.6                        ",
char far tbl_output_6_2_8[] = "2.7                        ",

char far tbl_output_6_3_1[] = "3.0                        ",
char far tbl_output_6_3_2[] = "3.1                        ",
char far tbl_output_6_3_3[] = "3.2                        ",
char far tbl_output_6_3_4[] = "3.3                        ",
char far tbl_output_6_3_5[] = "3.4                        ",
char far tbl_output_6_3_6[] = "3.5                        ",
char far tbl_output_6_3_7[] = "3.6                        ",
char far tbl_output_6_3_8[] = "3.7                        ",

char far tbl_output_6_4_1[] = "4.0                        ",
char far tbl_output_6_4_2[] = "4.1                        ",
char far tbl_output_6_4_3[] = "4.2                        ",
char far tbl_output_6_4_4[] = "4.3                        ",
char far tbl_output_6_4_5[] = "4.4                        ",
char far tbl_output_6_4_6[] = "4.5                        ",
char far tbl_output_6_4_7[] = "4.5                        ",
char far tbl_output_6_4_8[] = "4.7                        ",


/* INPUT CARD: 32OUT7 **/
/***********************/
char far tbl_output_7_1_1[] = "1.0                        ",
char far tbl_output_7_1_2[] = "1.1                        ",
char far tbl_output_7_1_3[] = "1.2                        ",
char far tbl_output_7_1_4[] = "1.3                        ",
char far tbl_output_7_1_5[] = "1.4                        ",
char far tbl_output_7_1_6[] = "1.5                        ",
char far tbl_output_7_1_7[] = "1.6                        ",
char far tbl_output_7_1_8[] = "1.7                        ",

char far tbl_output_7_2_1[] = "2.0                        ",
char far tbl_output_7_2_2[] = "2.1                        ",
char far tbl_output_7_2_3[] = "2.2                        ",
char far tbl_output_7_2_4[] = "2.3                        ",
char far tbl_output_7_2_5[] = "2.4                        ",
char far tbl_output_7_2_6[] = "2.5                        ",
char far tbl_output_7_2_7[] = "2.6                        ",
char far tbl_output_7_2_8[] = "2.7                        ",

char far tbl_output_7_3_1[] = "3.0                        ",
char far tbl_output_7_3_2[] = "3.1                        ",
char far tbl_output_7_3_3[] = "3.2                        ",
char far tbl_output_7_3_4[] = "3.3                        ",
char far tbl_output_7_3_5[] = "3.4                        ",
char far tbl_output_7_3_6[] = "3.5                        ",
char far tbl_output_7_3_7[] = "3.6                        ",
char far tbl_output_7_3_8[] = "3.7                        ",

char far tbl_output_7_4_1[] = "4.0                        ",
char far tbl_output_7_4_2[] = "4.1                        ",
char far tbl_output_7_4_3[] = "4.2                        ",
char far tbl_output_7_4_4[] = "4.3                        ",
char far tbl_output_7_4_5[] = "4.4                        ",
char far tbl_output_7_4_6[] = "4.5                        ",
char far tbl_output_7_4_7[] = "4.5                        ",
char far tbl_output_7_4_8[] = "4.7                        ",


/* INPUT CARD: 32OUT8 **/
/***********************/
char far tbl_output_8_1_1[] = "1.0                        ",
char far tbl_output_8_1_2[] = "1.1                        ",
char far tbl_output_8_1_3[] = "1.2                        ",
char far tbl_output_8_1_4[] = "1.3                        ",
char far tbl_output_8_1_5[] = "1.4                        ",
char far tbl_output_8_1_6[] = "1.5                        ",
char far tbl_output_8_1_7[] = "1.6                        ",
char far tbl_output_8_1_8[] = "1.7                        ",

char far tbl_output_8_2_1[] = "2.0                        ",
char far tbl_output_8_2_2[] = "2.1                        ",
char far tbl_output_8_2_3[] = "2.2                        ",
char far tbl_output_8_2_4[] = "2.3                        ",
char far tbl_output_8_2_5[] = "2.4                        ",
char far tbl_output_8_2_6[] = "2.5                        ",
char far tbl_output_8_2_7[] = "2.6                        ",
char far tbl_output_8_2_8[] = "2.7                        ",

char far tbl_output_8_3_1[] = "3.0                        ",
char far tbl_output_8_3_2[] = "3.1                        ",
char far tbl_output_8_3_3[] = "3.2                        ",
char far tbl_output_8_3_4[] = "3.3                        ",
char far tbl_output_8_3_5[] = "3.4                        ",
char far tbl_output_8_3_6[] = "3.5                        ",
char far tbl_output_8_3_7[] = "3.6                        ",
char far tbl_output_8_3_8[] = "3.7                        ",

char far tbl_output_8_4_1[] = "4.0                        ",
char far tbl_output_8_4_2[] = "4.1                        ",
char far tbl_output_8_4_3[] = "4.2                        ",
char far tbl_output_8_4_4[] = "4.3                        ",
char far tbl_output_8_4_5[] = "4.4                        ",
char far tbl_output_8_4_6[] = "4.5                        ",
char far tbl_output_8_4_7[] = "4.5                        ",
char far tbl_output_8_4_8[] = "4.7                        ",


/* INPUT CARD: 32OUT9 **/
/***********************/
char far tbl_output_9_1_1[] = "1.0                        ",
char far tbl_output_9_1_2[] = "1.1                        ",
char far tbl_output_9_1_3[] = "1.2                        ",
char far tbl_output_9_1_4[] = "1.3                        ",
char far tbl_output_9_1_5[] = "1.4                        ",
char far tbl_output_9_1_6[] = "1.5                        ",
char far tbl_output_9_1_7[] = "1.6                        ",
char far tbl_output_9_1_8[] = "1.7                        ",

char far tbl_output_9_2_1[] = "2.0                        ",
char far tbl_output_9_2_2[] = "2.1                        ",
char far tbl_output_9_2_3[] = "2.2                        ",
char far tbl_output_9_2_4[] = "2.3                        ",
char far tbl_output_9_2_5[] = "2.4                        ",
char far tbl_output_9_2_6[] = "2.5                        ",
char far tbl_output_9_2_7[] = "2.6                        ",
char far tbl_output_9_2_8[] = "2.7                        ",

char far tbl_output_9_3_1[] = "3.0                        ",
char far tbl_output_9_3_2[] = "3.1                        ",
char far tbl_output_9_3_3[] = "3.2                        ",
char far tbl_output_9_3_4[] = "3.3                        ",
char far tbl_output_9_3_5[] = "3.4                        ",
char far tbl_output_9_3_6[] = "3.5                        ",
char far tbl_output_9_3_7[] = "3.6                        ",
char far tbl_output_9_3_8[] = "3.7                        ",

char far tbl_output_9_4_1[] = "4.0                        ",
char far tbl_output_9_4_2[] = "4.1                        ",
char far tbl_output_9_4_3[] = "4.2                        ",
char far tbl_output_9_4_4[] = "4.3                        ",
char far tbl_output_9_4_5[] = "4.4                        ",
char far tbl_output_9_4_6[] = "4.5                        ",
char far tbl_output_9_4_7[] = "4.5                        ",
char far tbl_output_9_4_8[] = "4.7                        ",


/* CAN_STATION_1 32OUT P01->P04 **/
/*********************************/
char far tbl_output_S1_01_1[] = "1.1.1 Run Rotation CP FRONT",
char far tbl_output_S1_01_2[] = "1.1.2 Run Rotation CP BACK ",
char far tbl_output_S1_01_3[] = "1.1.3 Run Motor Insertion  ",
char far tbl_output_S1_01_4[] = "1.1.4 Rotation SR BRAKE-OFF",
char far tbl_output_S1_01_5[] = "1#1#5 Run Trims-Aspirator  ",
char far tbl_output_S1_01_6[] = "1.1.6 ...                  ",
char far tbl_output_S1_01_7[] = "1.1.7                      ",
char far tbl_output_S1_01_8[] = "1.1.8                      ",

char far tbl_output_S1_02_1[] = "1.2.1 Out RED Lamp ON      ",
char far tbl_output_S1_02_2[] = "1.2.2 Out ORANGE Lamp ON   ",
char far tbl_output_S1_02_3[] = "1.2.3 Out WHIYE Lamp ON    ",
char far tbl_output_S1_02_4[] = "1.2.4 Out GREEN Lamp ON    ",
char far tbl_output_S1_02_5[] = "1.2.5 Out BUZZER(HORN) ON  ",
char far tbl_output_S1_02_6[] = "1#2#6 SlowSpeedDoors UNLOCK",
char far tbl_output_S1_02_7[] = "1.2.7                      ",
char far tbl_output_S1_02_8[] = "1.2.8                      ",
                                                            
char far tbl_output_S1_03_1[] = "1.3.1 Out To Line: DEFG    ",
char far tbl_output_S1_03_2[] = "1.3.2 Out To Line: PRET    ",
char far tbl_output_S1_03_3[] = "1.3.3 Out To Line: DEFS    ",
char far tbl_output_S1_03_4[] = "1.3.4 Out To Line: DAR     ",
char far tbl_output_S1_03_5[] = "1.3.5 Out SOFTWARE-WATCHDOG",
char far tbl_output_S1_03_6[] = "1.3.6 ZeroSpeedDoors UNLOCK",
char far tbl_output_S1_03_7[] = "1.3.7                      ",
char far tbl_output_S1_03_8[] = "1.3.8                      ",
                                                            
char far tbl_output_S1_04_1[] = "1#4#1 ENABLE TranslTable   ",
char far tbl_output_S1_04_2[] = "1.4.2 ...                  ",
char far tbl_output_S1_04_3[] = "1#4#3 RESET SafetyBarrier  ",
char far tbl_output_S1_04_4[] = "1.4.4 ...                  ",
char far tbl_output_S1_04_5[] = "1.4.5 ...                  ",
char far tbl_output_S1_04_6[] = "1.4.6 ...                  ",
char far tbl_output_S1_04_7[] = "1.4.7                      ",
char far tbl_output_S1_04_8[] = "1.4.8                      ",


/* CAN_STATION_1 32OUT P05->P08 **/
/*********************************/
char far tbl_output_S1_05_1[] = "1.5.1                      ",
char far tbl_output_S1_05_2[] = "1.5.2                      ",
char far tbl_output_S1_05_3[] = "1.5.3                      ",
char far tbl_output_S1_05_4[] = "1.5.4                      ",
char far tbl_output_S1_05_5[] = "1.5.5                      ",
char far tbl_output_S1_05_6[] = "1.5.6                      ",
char far tbl_output_S1_05_7[] = "1.5.7                      ",
char far tbl_output_S1_05_8[] = "1.5.8                      ",
                                                             
char far tbl_output_S1_05_1[] = "1.6.1                      ",
char far tbl_output_S1_06_2[] = "1.6.2                      ",
char far tbl_output_S1_06_3[] = "1.6.3                      ",
char far tbl_output_S1_06_4[] = "1.6.4                      ",
char far tbl_output_S1_06_5[] = "1.6.5                      ",
char far tbl_output_S1_06_6[] = "1.6.6                      ",
char far tbl_output_S1_06_7[] = "1.6.7                      ",
char far tbl_output_S1_06_8[] = "1.6.8                      ",
                                                             
char far tbl_output_S1_07_1[] = "1.7.1                      ",
char far tbl_output_S1_07_2[] = "1.7.2                      ",
char far tbl_output_S1_07_3[] = "1.7.3                      ",
char far tbl_output_S1_07_4[] = "1.7.4                      ",
char far tbl_output_S1_07_5[] = "1.7.5                      ",
char far tbl_output_S1_07_6[] = "1.7.6                      ",
char far tbl_output_S1_07_7[] = "1.7.7                      ",
char far tbl_output_S1_07_8[] = "1.7.8                      ",
                                                             
char far tbl_output_S1_08_1[] = "1.8.1                      ",
char far tbl_output_S1_08_2[] = "1.8.2                      ",
char far tbl_output_S1_08_3[] = "1.8.3                      ",
char far tbl_output_S1_08_4[] = "1.8.4                      ",
char far tbl_output_S1_08_5[] = "1.8.5                      ",
char far tbl_output_S1_08_6[] = "1.8.6                      ",
char far tbl_output_S1_08_7[] = "1.8.7                      ",
char far tbl_output_S1_08_8[] = "1.8.8                      ",


/* CAN_STATION_2 32OUT P01->P04 **/
/*********************************/
char far tbl_output_S2_01_1[] = "2.1.1 EV Rotation GCT-Blade",
char far tbl_output_S2_01_2[] = "2.1.2 ...                  ",
char far tbl_output_S2_01_3[] = "2.1.3 EV Transl.GCT WORK   ",
char far tbl_output_S2_01_4[] = "2.1.4 EV Transl.GCT REST   ",
char far tbl_output_S2_01_5[] = "2.1.5 EV Air-Blow-GCT ON   ",
char far tbl_output_S2_01_6[] = "2.1.6 ...                  ",
char far tbl_output_S2_01_7[] = "2.1.7                      ",
char far tbl_output_S2_01_8[] = "2.1.8                      ",
                                                             
char far tbl_output_S2_02_1[] = "2.2.1 EV AirSource-GCT WORK",
char far tbl_output_S2_02_2[] = "2.2.2 EV AirSource-GCT REST",
char far tbl_output_S2_02_3[] = "2.2.3 EV HookCS WORK(close)",
char far tbl_output_S2_02_4[] = "2.2.4 EV HookCS REST (open)",
char far tbl_output_S2_02_5[] = "2.2.5 EV TranslCP BRAKE-OFF",
char far tbl_output_S2_02_6[] = "2.2.6 ...                  ",
char far tbl_output_S2_02_7[] = "2.2.7                      ",
char far tbl_output_S2_02_8[] = "2.2.8                      ",
                                                             
char far tbl_output_S2_03_1[] = "2.3.1 EV HookCP WORK(close)",
char far tbl_output_S2_03_2[] = "2.3.2 EV HookCP REST (open)",
char far tbl_output_S2_03_3[] = "2#3#3 EV GCL/Shaft BrakeON ",
char far tbl_output_S2_03_4[] = "2#3#4 EV GCL/Shaft BrakeOFF",
char far tbl_output_S2_03_5[] = "2.3.5 EV BladesGCL Insert. ",
char far tbl_output_S2_03_6[] = "2.3.6 EV BladesGCL Removal ",
char far tbl_output_S2_03_7[] = "2.3.7                      ",
char far tbl_output_S2_03_8[] = "2.3.8                      ",
                                                                   
char far tbl_output_S2_04_1[] = "2#4#1 EV AxisDrive WORK(in)",
char far tbl_output_S2_04_2[] = "2#4#2 EV AxisDrive REST(ou)",
char far tbl_output_S2_04_3[] = "2#4#3 EV AxisDrive INFLATE ",
char far tbl_output_S2_04_4[] = "2.4.4 ...                  ",
char far tbl_output_S2_04_5[] = "2#4#5 EV ArmsMABF WORK (dw)",
char far tbl_output_S2_04_6[] = "2#4#6 EV ArmsMABF REST (up)",
char far tbl_output_S2_04_7[] = "2.4.7                      ",
char far tbl_output_S2_04_8[] = "2.4.8                      ",
                                                             
                                                       
/* CAN_STATION_2 32OUT P05->P08 **/                          
/*********************************/                          
char far tbl_output_S2_05_1[] = "2.5.1 EV Cam-MABF WORK (bk)",
char far tbl_output_S2_05_2[] = "2.5.2 EV Cam-MABF REST (fr)",
char far tbl_output_S2_05_3[] = "2.5.3 EV Cam-MABF Brake OFF",
char far tbl_output_S2_05_4[] = "2.5.4 ...                  ",
char far tbl_output_S2_05_5[] = "2#5#5 EV ReelBrake WORK(dw)",
char far tbl_output_S2_05_6[] = "2#5#6 EV ReelBrake REST(up)",
char far tbl_output_S2_05_7[] = "2.5.7                      ",
char far tbl_output_S2_05_8[] = "2.5.8                      ",
                                                             
char far tbl_output_S2_05_1[] = "2#6#1 EV Appl.RP2 WORK (up)",
char far tbl_output_S2_06_2[] = "2#6#2 EV Appl.RP2 REST (dw)",
char far tbl_output_S2_06_3[] = "2.6.3 EV TranslCP WORK (up)",
char far tbl_output_S2_06_4[] = "2.6.4 EV TranslCP REST (dw)",
char far tbl_output_S2_06_5[] = "2.6.5 EV TranslCS WORK (fr)",
char far tbl_output_S2_06_6[] = "2.6.6 EV TranslCS WORK (bk)",
char far tbl_output_S2_06_7[] = "2.6.7                      ",
char far tbl_output_S2_06_8[] = "2.6.8                      ",
                                                             
char far tbl_output_S2_07_1[] = "2.7.1                      ",
char far tbl_output_S2_07_2[] = "2.7.2                      ",
char far tbl_output_S2_07_3[] = "2.7.3                      ",
char far tbl_output_S2_07_4[] = "2.7.4                      ",
char far tbl_output_S2_07_5[] = "2.7.5                      ",
char far tbl_output_S2_07_6[] = "2.7.6                      ",
char far tbl_output_S2_07_7[] = "2.7.7                      ",
char far tbl_output_S2_07_8[] = "2.7.8                      ",
                                                             
char far tbl_output_S2_08_1[] = "2.8.1                      ",
char far tbl_output_S2_08_2[] = "2.8.2                      ",
char far tbl_output_S2_08_3[] = "2.8.3                      ",
char far tbl_output_S2_08_4[] = "2.8.4                      ",
char far tbl_output_S2_08_5[] = "2.8.5                      ",
char far tbl_output_S2_08_6[] = "2.8.6                      ",
char far tbl_output_S2_08_7[] = "2.8.7                      ",
char far tbl_output_S2_08_8[] = "2.8.8                      ",


/* CAN_STATION_3 32OUT P01->P04 **/
/*********************************/
char far tbl_output_S3_01_1[] = "3#1#1 ENABLE Crane         ",
char far tbl_output_S3_01_2[] = "3#1#2 Crane Remote Control ",
char far tbl_output_S3_01_3[] = "3#1#3 TranslCrane Forward  ",
char far tbl_output_S3_01_4[] = "3#1#4 TranslCrane Backward ",
char far tbl_output_S3_01_5[] = "3#1#5 TranslCrane FastSpeed",
char far tbl_output_S3_01_6[] = "3#1#6 Vertical Crane Up    ",
char far tbl_output_S3_01_7[] = "3.1.7                      ",
char far tbl_output_S3_01_8[] = "3.1.8                      ",
                                                            
char far tbl_output_S3_02_1[] = "3#2#1 Vertical Crane Down  ",
char far tbl_output_S3_02_2[] = "3#2#2 Vert. Crane_FastSpeed",
char far tbl_output_S3_02_3[] = "3#2#3 Rotat.ArmCrane toWork",
char far tbl_output_S3_02_4[] = "3#2#4 Rotat.ArmCrane toRest",
char far tbl_output_S3_02_5[] = "3#2#5 PliersGroup toWork   ",
char far tbl_output_S3_02_6[] = "3#2#6 PliersGroup toRest   ",
char far tbl_output_S3_02_7[] = "3.2.7                      ",
char far tbl_output_S3_02_8[] = "3.2.8                      ",
                                                            
char far tbl_output_S3_03_1[] = "3.3.1 ...                  ",
char far tbl_output_S3_03_2[] = "3#3#2 Pliers toWork        ",
char far tbl_output_S3_03_3[] = "3#3#3 Pliers toRest        ",
char far tbl_output_S3_03_4[] = "3#3#4 Vice toWork          ",
char far tbl_output_S3_03_5[] = "3#3#5 Vice toRest          ",
char far tbl_output_S3_03_6[] = "3.3.6 ...                  ",
char far tbl_output_S3_03_7[] = "3.3.7                      ",
char far tbl_output_S3_03_8[] = "3.3.8                      ",
                                                            
char far tbl_output_S3_04_1[] = "3#4#1 Pin toWork           ",
char far tbl_output_S3_04_2[] = "3#4#2 Pin toRest           ",
char far tbl_output_S3_04_3[] = "3#4#3 AirPin ON            ",
char far tbl_output_S3_04_4[] = "3#4#4 AirPin OFF           ",
char far tbl_output_S3_04_5[] = "3#4#5 Crane FaultReset     ",
char far tbl_output_S3_04_6[] = "3.4.6 Crane Automatic Mode ",
char far tbl_output_S3_04_7[] = "3.4.7                      ",
char far tbl_output_S3_04_8[] = "3.4.8                      ",


/* CAN_STATION_3 32OUT P05->P08 **/
/*********************************/
char far tbl_output_S3_05_1[] = "3.5.1                      ",
char far tbl_output_S3_05_2[] = "3.5.2                      ",
char far tbl_output_S3_05_3[] = "3.5.3                      ",
char far tbl_output_S3_05_4[] = "3.5.4                      ",
char far tbl_output_S3_05_5[] = "3.5.5                      ",
char far tbl_output_S3_05_6[] = "3.5.6                      ",
char far tbl_output_S3_05_7[] = "3.5.7                      ",
char far tbl_output_S3_05_8[] = "3.5.8                      ",
                                                            
char far tbl_output_S3_05_1[] = "3.6.1                      ",
char far tbl_output_S3_06_2[] = "3.6.2                      ",
char far tbl_output_S3_06_3[] = "3.6.3                      ",
char far tbl_output_S3_06_4[] = "3.6.4                      ",
char far tbl_output_S3_06_5[] = "3.6.5                      ",
char far tbl_output_S3_06_6[] = "3.6.6                      ",
char far tbl_output_S3_06_7[] = "3.6.7                      ",
char far tbl_output_S3_06_8[] = "3.6.8                      ",
                                                            
char far tbl_output_S3_07_1[] = "3.7.1                      ",
char far tbl_output_S3_07_2[] = "3.7.2                      ",
char far tbl_output_S3_07_3[] = "3.7.3                      ",
char far tbl_output_S3_07_4[] = "3.7.4                      ",
char far tbl_output_S3_07_5[] = "3.7.5                      ",
char far tbl_output_S3_07_6[] = "3.7.6                      ",
char far tbl_output_S3_07_7[] = "3.7.7                      ",
char far tbl_output_S3_07_8[] = "3.7.8                      ",
                                                            
char far tbl_output_S3_08_1[] = "3.8.1                      ",
char far tbl_output_S3_08_2[] = "3.8.2                      ",
char far tbl_output_S3_08_3[] = "3.8.3                      ",
char far tbl_output_S3_08_4[] = "3.8.4                      ",
char far tbl_output_S3_08_5[] = "3.8.5                      ",
char far tbl_output_S3_08_6[] = "3.8.6                      ",
char far tbl_output_S3_08_7[] = "3.8.7                      ",
char far tbl_output_S3_08_8[] = "3.8.8                      ",


/* CAN_STATION_4 32OUT P01->P04 **/
/*********************************/
char far tbl_output_S4_01_1[] = "4.1.1                      ",
char far tbl_output_S4_01_2[] = "4.1.2                      ",
char far tbl_output_S4_01_3[] = "4.1.3                      ",
char far tbl_output_S4_01_4[] = "4.1.4                      ",
char far tbl_output_S4_01_5[] = "4.1.5                      ",
char far tbl_output_S4_01_6[] = "4.1.6                      ",
char far tbl_output_S4_01_7[] = "4.1.7                      ",
char far tbl_output_S4_01_8[] = "4.1.8                      ",
                                                            
char far tbl_output_S4_02_1[] = "4.2.1                      ",
char far tbl_output_S4_02_2[] = "4.2.2                      ",
char far tbl_output_S4_02_3[] = "4.2.3                      ",
char far tbl_output_S4_02_4[] = "4.2.4                      ",
char far tbl_output_S4_02_5[] = "4.2.5                      ",
char far tbl_output_S4_02_6[] = "4.2.6                      ",
char far tbl_output_S4_02_7[] = "4.2.7                      ",
char far tbl_output_S4_02_8[] = "4.2.8                      ",
                                                            
char far tbl_output_S4_03_1[] = "4.3.1                      ",
char far tbl_output_S4_03_2[] = "4.3.2                      ",
char far tbl_output_S4_03_3[] = "4.3.3                      ",
char far tbl_output_S4_03_4[] = "4.3.4                      ",
char far tbl_output_S4_03_5[] = "4.3.5                      ",
char far tbl_output_S4_03_6[] = "4.3.6                      ",
char far tbl_output_S4_03_7[] = "4.3.7                      ",
char far tbl_output_S4_03_8[] = "4.3.8                      ",
                                                            
char far tbl_output_S4_04_1[] = "4.4.1                      ",
char far tbl_output_S4_04_2[] = "4.4.2                      ",
char far tbl_output_S4_04_3[] = "4.4.3                      ",
char far tbl_output_S4_04_4[] = "4.4.4                      ",
char far tbl_output_S4_04_5[] = "4.4.5                      ",
char far tbl_output_S4_04_6[] = "4.4.6                      ",
char far tbl_output_S4_04_7[] = "4.4.7                      ",
char far tbl_output_S4_04_8[] = "4.4.8                      ",


/* CAN_STATION_4 32OUT P05->P08 **/
/*********************************/
char far tbl_output_S4_05_1[] = "4.5.1                      ",
char far tbl_output_S4_05_2[] = "4.5.2                      ",
char far tbl_output_S4_05_3[] = "4.5.3                      ",
char far tbl_output_S4_05_4[] = "4.5.4                      ",
char far tbl_output_S4_05_5[] = "4.5.5                      ",
char far tbl_output_S4_05_6[] = "4.5.6                      ",
char far tbl_output_S4_05_7[] = "4.5.7                      ",
char far tbl_output_S4_05_8[] = "4.5.8                      ",
                                                            
char far tbl_output_S4_05_1[] = "4.6.1                      ",
char far tbl_output_S4_06_2[] = "4.6.2                      ",
char far tbl_output_S4_06_3[] = "4.6.3                      ",
char far tbl_output_S4_06_4[] = "4.6.4                      ",
char far tbl_output_S4_06_5[] = "4.6.5                      ",
char far tbl_output_S4_06_6[] = "4.6.6                      ",
char far tbl_output_S4_06_7[] = "4.6.7                      ",
char far tbl_output_S4_06_8[] = "4.6.8                      ",
                                                            
char far tbl_output_S4_07_1[] = "4.7.1                      ",
char far tbl_output_S4_07_2[] = "4.7.2                      ",
char far tbl_output_S4_07_3[] = "4.7.3                      ",
char far tbl_output_S4_07_4[] = "4.7.4                      ",
char far tbl_output_S4_07_5[] = "4.7.5                      ",
char far tbl_output_S4_07_6[] = "4.7.6                      ",
char far tbl_output_S4_07_7[] = "4.7.7                      ",
char far tbl_output_S4_07_8[] = "4.7.8                      ",
                                                            
char far tbl_output_S4_08_1[] = "4.8.1                      ",
char far tbl_output_S4_08_2[] = "4.8.2                      ",
char far tbl_output_S4_08_3[] = "4.8.3                      ",
char far tbl_output_S4_08_4[] = "4.8.4                      ",
char far tbl_output_S4_08_5[] = "4.8.5                      ",
char far tbl_output_S4_08_6[] = "4.8.6                      ",
char far tbl_output_S4_08_7[] = "4.8.7                      ",
char far tbl_output_S4_08_8[] = "4.8.8                      ",
                                                            
                                                            
/* CAN_STATION_5 32OUT P01->P04 **/                         
/*********************************/                         
char far tbl_output_S5_01_1[] = "5.1.1                      ",
char far tbl_output_S5_01_2[] = "5.1.2                      ",
char far tbl_output_S5_01_3[] = "5.1.3                      ",
char far tbl_output_S5_01_4[] = "5.1.4                      ",
char far tbl_output_S5_01_5[] = "5.1.5                      ",
char far tbl_output_S5_01_6[] = "5.1.6                      ",
char far tbl_output_S5_01_7[] = "5.1.7                      ",
char far tbl_output_S5_01_8[] = "5.1.8                      ",
                                                            
char far tbl_output_S5_02_1[] = "5.2.1                      ",
char far tbl_output_S5_02_2[] = "5.2.2                      ",
char far tbl_output_S5_02_3[] = "5.2.3                      ",
char far tbl_output_S5_02_4[] = "5.2.4                      ",
char far tbl_output_S5_02_5[] = "5.2.5                      ",
char far tbl_output_S5_02_6[] = "5.2.6                      ",
char far tbl_output_S5_02_7[] = "5.2.7                      ",
char far tbl_output_S5_02_8[] = "5.2.8                      ",
                                                            
char far tbl_output_S5_03_1[] = "5.3.1                      ",
char far tbl_output_S5_03_2[] = "5.3.2                      ",
char far tbl_output_S5_03_3[] = "5.3.3                      ",
char far tbl_output_S5_03_4[] = "5.3.4                      ",
char far tbl_output_S5_03_5[] = "5.3.5                      ",
char far tbl_output_S5_03_6[] = "5.3.6                      ",
char far tbl_output_S5_03_7[] = "5.3.7                      ",
char far tbl_output_S5_03_8[] = "5.3.8                      ",
                                                            
char far tbl_output_S5_04_1[] = "5.4.1                      ",
char far tbl_output_S5_04_2[] = "5.4.2                      ",
char far tbl_output_S5_04_3[] = "5.4.3                      ",
char far tbl_output_S5_04_4[] = "5.4.4                      ",
char far tbl_output_S5_04_5[] = "5.4.5                      ",
char far tbl_output_S5_04_6[] = "5.4.6                      ",
char far tbl_output_S5_04_7[] = "5.4.7                      ",
char far tbl_output_S5_04_8[] = "5.4.8                      ",
                                                            
                                                            
/* CAN_STATION_5 32OUT P05->P08 **/                         
/*********************************/                         
char far tbl_output_S5_05_1[] = "5.5.1                      ",
char far tbl_output_S5_05_2[] = "5.5.2                      ",
char far tbl_output_S5_05_3[] = "5.5.3                      ",
char far tbl_output_S5_05_4[] = "5.5.4                      ",
char far tbl_output_S5_05_5[] = "5.5.5                      ",
char far tbl_output_S5_05_6[] = "5.5.6                      ",
char far tbl_output_S5_05_7[] = "5.5.7                      ",
char far tbl_output_S5_05_8[] = "5.5.8                      ",
                                                            
char far tbl_output_S5_05_1[] = "5.6.1                      ",
char far tbl_output_S5_06_2[] = "5.6.2                      ",
char far tbl_output_S5_06_3[] = "5.6.3                      ",
char far tbl_output_S5_06_4[] = "5.6.4                      ",
char far tbl_output_S5_06_5[] = "5.6.5                      ",
char far tbl_output_S5_06_6[] = "5.6.6                      ",
char far tbl_output_S5_06_7[] = "5.6.7                      ",
char far tbl_output_S5_06_8[] = "5.6.8                      ",
                                                            
char far tbl_output_S5_07_1[] = "5.7.1                      ",
char far tbl_output_S5_07_2[] = "5.7.2                      ",
char far tbl_output_S5_07_3[] = "5.7.3                      ",
char far tbl_output_S5_07_4[] = "5.7.4                      ",
char far tbl_output_S5_07_5[] = "5.7.5                      ",
char far tbl_output_S5_07_6[] = "5.7.6                      ",
char far tbl_output_S5_07_7[] = "5.7.7                      ",
char far tbl_output_S5_07_8[] = "5.7.8                      ",
                                                            
char far tbl_output_S5_08_1[] = "5.8.1                      ",
char far tbl_output_S5_08_2[] = "5.8.2                      ",
char far tbl_output_S5_08_3[] = "5.8.3                      ",
char far tbl_output_S5_08_4[] = "5.8.4                      ",
char far tbl_output_S5_08_5[] = "5.8.5                      ",
char far tbl_output_S5_08_6[] = "5.8.6                      ",
char far tbl_output_S5_08_7[] = "5.8.7                      ",
char far tbl_output_S5_08_8[] = "5.8.8                      ",







/* Table of the 6AXES                                    */
/* char *tbl_output[] =                                  */
/*                            123456789012345678901234567*/
char far tbl_6axes00[]     = "                           ",

/* CARD: 6AXES1        */
/***********************/
char far tbl_6axes_1_in1[] = "in1  ....                  ",
char far tbl_6axes_1_in2[] = "In2  ....                  ",
char far tbl_6axes_1_in3[] = "In3  ....                  ",
char far tbl_6axes_1_in4[] = "In4  ....                  ",
char far tbl_6axes_1_in5[] = "In5  ....                  ",
char far tbl_6axes_1_in6[] = "In6  ....                  ",

char far tbl_6axes_1_out1[]= "Out1 ....                  ",
char far tbl_6axes_1_out2[]= "Out2 ....                  ",
char far tbl_6axes_1_out3[]= "Out3 ....                  ",
char far tbl_6axes_1_out4[]= "Out4 ....                  ",
char far tbl_6axes_1_out5[]= "Out5 ....                  ",
char far tbl_6axes_1_out6[]= "Out6 ....                  ",

char far tbl_6axes_1_dac1[]= "Ana1 ....                  ",
char far tbl_6axes_1_dac2[]= "Ana2 ....                  ",
char far tbl_6axes_1_dac3[]= "Ana3 ....                  ",
char far tbl_6axes_1_dac4[]= "Ana4 ....                  ",
char far tbl_6axes_1_dac5[]= "Ana5 ....                  ",
char far tbl_6axes_1_dac6[]= "Ana6 ....                  ",

/* CARD: 6AXES2        */
/***********************/
char far tbl_6axes_2_in1[] = "in1  ....                  ",
char far tbl_6axes_2_in2[] = "In2  ....                  ",
char far tbl_6axes_2_in3[] = "In3  ....                  ",
char far tbl_6axes_2_in4[] = "In4  ....                  ",
char far tbl_6axes_2_in5[] = "In5  ....                  ",
char far tbl_6axes_2_in6[] = "In6  ....                  ",

char far tbl_6axes_2_out1[]= "Out1 ....                  ",
char far tbl_6axes_2_out2[]= "Out2 ....                  ",
char far tbl_6axes_2_out3[]= "Out3 ....                  ",
char far tbl_6axes_2_out4[]= "Out4 ....                  ",
char far tbl_6axes_2_out5[]= "Out5 ....                  ",
char far tbl_6axes_2_out6[]= "Out6 ....                  ",

char far tbl_6axes_2_dac1[]= "Ana1 ....                  ",
char far tbl_6axes_2_dac2[]= "Ana2 ....                  ",
char far tbl_6axes_2_dac3[]= "Ana3 ....                  ",
char far tbl_6axes_2_dac4[]= "Ana4 ....                  ",
char far tbl_6axes_2_dac5[]= "Ana5 ....                  ",
char far tbl_6axes_2_dac6[]= "Ana6 ....                  ",

/* CARD: 6AXES3        */
/***********************/
char far tbl_6axes_3_in1[] = "in1  ....                  ",
char far tbl_6axes_3_in2[] = "In2  ....                  ",
char far tbl_6axes_3_in3[] = "In3  ....                  ",
char far tbl_6axes_3_in4[] = "In4  ....                  ",
char far tbl_6axes_3_in5[] = "In5  ....                  ",
char far tbl_6axes_3_in6[] = "In6  ....                  ",

char far tbl_6axes_3_out1[]= "Out1 ....                  ",
char far tbl_6axes_3_out2[]= "Out2 ....                  ",
char far tbl_6axes_3_out3[]= "Out3 ....                  ",
char far tbl_6axes_3_out4[]= "Out4 ....                  ",
char far tbl_6axes_3_out5[]= "Out5 ....                  ",
char far tbl_6axes_3_out6[]= "Out6 ....                  ",

char far tbl_6axes_3_dac1[]= "Ana1 ....                  ",
char far tbl_6axes_3_dac2[]= "Ana2 ....                  ",
char far tbl_6axes_3_dac3[]= "Ana3 ....                  ",
char far tbl_6axes_3_dac4[]= "Ana4 ....                  ",
char far tbl_6axes_3_dac5[]= "Ana5 ....                  ",
char far tbl_6axes_3_dac6[]= "Ana6 ....                  ",

/* CARD: 6AXES4        */
/***********************/
char far tbl_6axes_4_in1[] = "in1  ....                  ",
char far tbl_6axes_4_in2[] = "In2  ....                  ",
char far tbl_6axes_4_in3[] = "In3  ....                  ",
char far tbl_6axes_4_in4[] = "In4  ....                  ",
char far tbl_6axes_4_in5[] = "In5  ....                  ",
char far tbl_6axes_4_in6[] = "In6  ....                  ",

char far tbl_6axes_4_out1[]= "Out1 ....                  ",
char far tbl_6axes_4_out2[]= "Out2 ....                  ",
char far tbl_6axes_4_out3[]= "Out3 ....                  ",
char far tbl_6axes_4_out4[]= "Out4 ....                  ",
char far tbl_6axes_4_out5[]= "Out5 ....                  ",
char far tbl_6axes_4_out6[]= "Out6 ....                  ",

char far tbl_6axes_4_dac1[]= "Ana1 ....                  ",
char far tbl_6axes_4_dac2[]= "Ana2 ....                  ",
char far tbl_6axes_4_dac3[]= "Ana3 ....                  ",
char far tbl_6axes_4_dac4[]= "Ana4 ....                  ",
char far tbl_6axes_4_dac5[]= "Ana5 ....                  ",
char far tbl_6axes_4_dac6[]= "Ana6 ....                  ",

/* CARD: 6AXES5        */
/***********************/
char far tbl_6axes_5_in1[] = "in1  ....                  ",
char far tbl_6axes_5_in2[] = "In2  ....                  ",
char far tbl_6axes_5_in3[] = "In3  ....                  ",
char far tbl_6axes_5_in4[] = "In4  ....                  ",
char far tbl_6axes_5_in5[] = "In5  ....                  ",
char far tbl_6axes_5_in6[] = "In6  ....                  ",

char far tbl_6axes_5_out1[]= "Out1 ....                  ",
char far tbl_6axes_5_out2[]= "Out2 ....                  ",
char far tbl_6axes_5_out3[]= "Out3 ....                  ",
char far tbl_6axes_5_out4[]= "Out4 ....                  ",
char far tbl_6axes_5_out5[]= "Out5 ....                  ",
char far tbl_6axes_5_out6[]= "Out6 ....                  ",

char far tbl_6axes_5_dac1[]= "Ana1 ....                  ",
char far tbl_6axes_5_dac2[]= "Ana2 ....                  ",
char far tbl_6axes_5_dac3[]= "Ana3 ....                  ",
char far tbl_6axes_5_dac4[]= "Ana4 ....                  ",
char far tbl_6axes_5_dac5[]= "Ana5 ....                  ",
char far tbl_6axes_5_dac6[]= "Ana6 ....                  ",


/* Table of the SPECFLY                                    */
/* char *tbl_specfly[] =                                   */
/*                              123456789012345678901234567*/
char far tbl_specfly00[]   =   "                           ",

/* CARD: SPECFLY1      */
/***********************/
char far tbl_specfly_1_out1[]= "OD1 ...                   ",
char far tbl_specfly_1_out2[]= "OD2 ...                   ",
char far tbl_specfly_1_out3[]= "OD3 ...                   ",
char far tbl_specfly_1_out4[]= "OD4 ...                   ",
char far tbl_specfly_1_out5[]= "OD5 ...                   ",
char far tbl_specfly_1_out6[]= "OD6 ...                   ",
char far tbl_specfly_1_out7[]= "OD7 ...                   ",
char far tbl_specfly_1_out8[]= "OD8 ...                   ",

char far tbl_specfly_1_dac1[]= "Ana1 ...                  ",
char far tbl_specfly_1_dac2[]= "Ana2 ...                  ",
char far tbl_specfly_1_dac3[]= "Ana3 ...                  ",
char far tbl_specfly_1_dac4[]= "Ana4 ...                  ",

/* ANALOG OUTPUT (CAN2)*/
/***********************/
char far tbl_anaout1[]= "CAN2#1#1 RotABF Torque    ",
char far tbl_anaout2[]= "CAN2#1#2 DANCER_BIS/SPEED ",
char far tbl_anaout3[]= "CAN2#1#3 RotRP2 Torque    ",
char far tbl_anaout4[]= "CAN2#1#4 ApplRP2 Pressure ",
char far tbl_anaout5[]= "CAN2.2.1 ApplCS Pressure  ",
char far tbl_anaout6[]= "CAN2.2.2 DANCER_MAIN Press",
char far tbl_anaout7[]= "CAN2.2.3 ApplWORK-CP Press",
char far tbl_anaout8[]= "CAN2.2.4 ApplREST-CP Press",


																