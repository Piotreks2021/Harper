
  SYSTEM CIECIA - STEROWANIE RECZNE     X


     OBROT W PRZOD        OBROT W TYL
          [1]                 [2]       

 
    NADMUCH WLACZONY    NADMUCH WYLACZON
          [3]                 [4]       


      NOZ W PRZOD          NOZ W TYL
          [5]                 [6]       


     OSTRZE WLACZONE    OSTRZE WYLACZONE
          [7]                 [8]       


    NADMUCH WLACZONY    NADMUCH WYLACZON
          [9]                 [F1]       



12345678901234567890123456789012345678901234
  
----xxxxxxxxxxxxxxxx----xxxxxxxxxxxxxxxx----
  
