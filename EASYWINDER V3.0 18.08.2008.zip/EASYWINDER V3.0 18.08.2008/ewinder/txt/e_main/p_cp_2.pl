
  RAMIONA GL. (CP) STEROWANIE RECZNE    X


       BLOK. WAL           ODBLOK. WAL
          [1]                 [2]       


      ZALOZ NAPED          USUN NAPED
          [3]                 [4]       


     NAPEL. NAPED         UPUSC NAPED
          [5]                 [6]       


      OBROC PRZOD          OBROC TYL
          [7]                 [8]       


      RAMIONA GORA        RAMIONA DOL
          [9]                 [F1]       


     RAMIONA PRZOD        RAMIONA TYL
          [F2]                [F3]       


    MINIMALNA SREDN.



----xxxxxxxxxxxxxxxx----xxxxxxxxxxxxxxxx----  
12345678901234567890123456789012345678901234
