
  NACISNAC OK, ABY POTWIERDZIC POLECENIE
  URUCHOMIENIA ZMIANY AUTOMATYCZNEJ  
                                          
                       OK       ANULUJ
                                          
                                          

                    xxxxxxxxx  xxxxxxxxx
  